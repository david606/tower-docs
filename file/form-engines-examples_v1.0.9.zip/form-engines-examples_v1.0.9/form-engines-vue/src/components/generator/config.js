// 表单属性【右面板】
export const formConf = {
  formRef: 'elForm',
  formTitle: '表单标题',
  formModel: 'formData',
  size: 'medium',
  labelPosition: 'right',
  labelWidth: 100,
  formRules: 'rules',
  gutter: 15,
  span: 24,
  formBtns: true,
  unFocusedComponentBorder: true,
  fields: []
}
