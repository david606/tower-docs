<template>
  <div class="edit">
    <ct-edit-form :uuid="uuid" :mode="mode" :initExternal="initExternal" :showAllComponents="true" :showComponents="showComponents"></ct-edit-form >
  </div>
</template>
<script>
export default {
  name: 'EditForm',
  components: {
  },
  props: {
    uuid: {
      // 表格uuid，默认为空
      type: String,
      default: () => ''
    },
    mode: {
      // 编辑模式，custom/developer，默认为custom
      type: String,
      default: () => 'custom'
    },
    initExternal: {
      // 左侧菜单加载扩展组件, 默认为true
      type: Boolean,
      default: () => true
    },
    showAllComponents: {
      // 左侧菜单展示所有组件
      type: Boolean,
      default: () => false
    },
    showComponents: {
      // 左侧菜单展示的组件,,当showAllComponents为false时生效
      // input 为输入型组件,select为选择型组件,layout为布局型组件,business为业务型组件
      type: Object,
      default: () => ({
        input: ['单行文本', '多行文本', '密码', '计数器'],
        select: ['下拉选择', '级联选择', '单选框组', '多选框组', '开关', '滑块', '时间选择', '时间范围', '日期选择', '日期范围', '文字链接'],
        layout: ['行容器'],
        business: ['性别', '扩展测试']
      })
    }
  }
}

</script>
