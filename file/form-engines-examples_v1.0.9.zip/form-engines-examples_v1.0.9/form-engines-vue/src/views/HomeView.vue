<template>
  <div class="manage">
    <ct-manage-form></ct-manage-form>
  </div>
</template>

<script>

export default {
  name: 'HomeView',
  components: {
    // HelloWorld
  }
}
</script>
