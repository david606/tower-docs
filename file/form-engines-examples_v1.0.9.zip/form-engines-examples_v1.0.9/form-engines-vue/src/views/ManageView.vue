<template>
  <div class="common-layout">
    <el-container>
      <el-header>
        <div class="logo-wrapper" style="height: 60px;">
          <div class="logo">
            <img src="@/assets/logo-chinatower.png" alt="logo">
            <span style="margin-left: 20px;display: block;float: right;margin-top: 10px;">表单引擎</span>
          </div>
        </div>
      </el-header>
      <el-main style="margin: 0 auto; width: 85%;">
        <div class="mod-condition">
          <div class="_title clearfix">
            <span />
            <label>表单查询</label>
          </div>
          <div class="clearfix">
            <el-form :inline="true" :model="criteria" class="demo-form-inline" style="margin-top: 2%;">
              <el-form-item label="表单名称">
                <el-input v-model="criteria.name" placeholder="按表单名称搜索" />
              </el-form-item>
              <el-form-item>
                <el-button type="primary" @click="onSearch">
                  查询
                </el-button>
                <el-button type="primary" @click="onReset">
                  重置
                </el-button>
              </el-form-item>
              <el-form-item style="float: right">
                <el-button type="primary" @click="onAddNew">
                  创建表单
                </el-button>
              </el-form-item>
            </el-form>
          </div>
        </div>

        <div class="mod-result-table">
          <div class="_title clearfix">
            <div class="f-l">
              <span />
              <label>查询结果</label>
              <p>共有<span>{{ tableTotalSize }}</span>条查询结果</p>
            </div>
          </div>
          <el-table
            :data="resultTableData"
            style="width: 100%"
            border="border"
            stripe
          >
            <el-table-column
              prop="#info.id"
              label="表单ID"
              align="center"
              width="325px"
            />
            <el-table-column
              prop="name"
              label="表单名称"
              align="center"
            />
            <el-table-column
              prop="formTitle"
              label="表单标题"
              align="center"
            />
            <el-table-column
              prop="formRef"
              label="表单引用名称"
              align="center"
            />
            <el-table-column
              prop="formModel"
              label="数据模型"
              align="center"
            />
            <el-table-column
              prop="#info.createTime"
              label="创建日期"
              align="center"
              width="170px"
            >
              <template #default="scope">
                {{ new String(scope.row['#info']?.createTime).replace(/[A-Za-z]/, ' ') }}
              </template>
            </el-table-column>
            <el-table-column
              fixed="right"
              label="操作"
              align="center"
              width="300px"
            >
              <template #default="scope">
                <el-button type="text" :loading="formDataLoding" :disabled="scope.row['#info']?.disabled == 1">
                  <router-link :to="{ name: 'form_engines_parser', params: { uuid: scope.row['#info']?.id } }"
                               target="_blank" style="border: none;text-decoration: none;"
                               :class="{
                                 disabledLink: scope.row['#info']?.disabled == 1,
                                 link: scope.row['#info']?.disabled == 0
                               }"
                  >
                    预览
                  </router-link>
                </el-button>
                <el-button type="text" :loading="formDataLoding" :disabled="scope.row['#info']?.disabled == 1"
                           :class="{
                             disabledButton: scope.row['#info']?.disabled == 1
                           }"
                           @click="onEdit(scope.index, scope.row)"
                >
                  编辑
                </el-button>
                <!--  todo 查看数据表数据 -->
                <!-- <el-button type="text" @click="onData(scope.index, scope.row)">
                  查看数据
                </el-button> -->
                <el-button type="text" :loading="formDataLoding" @click="onDelete(scope.index, scope.row)">
                  删除
                </el-button>
                <el-button type="text" :loading="formDataLoding" @click="onCopy(scope.index, scope.row)">
                  复制
                </el-button>
                <el-button type="text" :loading="formDataLoding" @click="onRebuild(scope.index, scope.row)">
                  重建
                </el-button>
                <el-button v-if="scope.row['#info']?.disabled==0" type="text"
                           :loading="formDataLoding"
                           @click="changeDisabledStatus(scope.row, 1)"
                >
                  禁用
                </el-button>
                <el-button v-else :loading="formDataLoding" type="text" @click="changeDisabledStatus(scope.row, 0)">
                  启用
                </el-button>
              </template>
            </el-table-column>
          </el-table>
          <el-pagination
            class="mod-pagination"
            popper-class="mod-pagination-select"
            :current-page.sync="currentPage"
            :page-sizes="[10, 20, 50, 100]"
            :page-size="pageSize"
            layout="prev,  pager, next,slot,total, sizes "
            :total="tableTotalSize"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
          >
            <span class="txt">到第</span>
            <input v-model="toPage" class="input-txt" type="text">
            <span class="txt">页</span>
            <button class="btn" @click="handleCurrentClick(toPage)">
              确定
            </button>
          </el-pagination>
        </div>

        <el-dialog
          top="5vh"
          custom-class="dialog-visible ability_detail"
          title="创建表单"
          destroy-on-close
          :visible.sync="showAddNewDialog"
        >
          <div slot="title">
            <span>创建表单</span>
          </div>
          <div style="height: 300px;">
            <el-steps :active="step" align-center finish-status="success">
              <el-step title="生成表单" description="创建新表单页" />
              <el-step title="样式配置" description="编辑表单样式" />
            </el-steps>
            <div v-show="step == 0" class="mod-condition">
              <div class="_title clearfix">
                <span />
                <label>创建新表单页面</label>
              </div>
              <el-form ref="addNewForm" :model="formData"
                       class="demo-form-inline" style="width: 85%;height: 120px;" label-width="30%"
                       size="mini"
                       :rules="newFormRules"
                       :loading="formDataLoding"
              >
                <el-form-item label="表单名称" style="margin-top: 12%;" prop="name" maxlength="40">
                  <el-input v-model="formData.name" placeholder="请输入表单名称" />
                  <span style="position: absolute; right: 10px; bottom: 0; font-size: 10px; opacity: 0.6">
                    {{ formNameMaxLenth(formData.name, 40) }}
                  </span>
                </el-form-item>
              </el-form>
            </div>
            <div v-show="step == 1" class="mod-condition" style="height: 120px;text-align: center;">
              <label style="margin-top: 12%;">
                <span class="el-icon-circle-check" style="color: #67C23A; font-size: 70px;justify-content:center" />
                <span style="font-size: 20px;">点击编辑,进入表单编辑页面</span>
              </label>
            </div>
          </div>
          <template #footer>
            <span class="dialog-footer">
              <el-button @click="closeDialog">取消</el-button>
              <el-button v-show="step < 1" type="primary" :loading="formDataLoding"
                         @click="addNewForm('addNewForm')"
              >创建</el-button>
              <el-button v-show="step == 1" type="primary" @click="complete(formData['#info'].id)">编辑表单</el-button>
            </span>
          </template>
        </el-dialog>

        <el-dialog
          top="5vh"
          custom-class="dialog-visible ability_detail"
          title="编辑表单"
          destroy-on-close
          :visible.sync="showEditDialog"
        >
          <div slot="title">
            <span>编辑表单</span>
          </div>
          <div style="height: 300px;">
            <div class="mod-condition">
              <div class="_title clearfix">
                <span />
                <label>编辑表单页面</label>
              </div>
              <el-form :key="fresh"
                       ref="updateForm"
                       v-loading="formDataLoding" :model="formData" class="demo-form-inline"
                       style="width: 85%;height: 180px;"
                       label-width="30%"
                       size="mini"
                       :rules="newFormRules"
              >
                <el-form-item label="表单名称" style="margin-top: 12%;" prop="name" maxlength="40">
                  <el-input v-model="formData.name" placeholder="请输入表单名称" />
                  <span style="position: absolute; right: 10px; bottom: 0; font-size: 10px; opacity: 0.6">
                    {{ formNameMaxLenth(formData.name, 40) }}
                  </span>
                </el-form-item>
                <!-- <el-form-item prop="editFormTitle">
                  <el-checkbox v-model="formData.editFormTitle" @change="freshForm">
                    同步修改表单标题(与当前名称相同)
                  </el-checkbox>
                </el-form-item>
                <el-form-item prop="editFormModel">
                  <el-checkbox v-model="formData.editFormModel" @change="freshForm">
                    同步修改数据模型(为当前名称拼音)
                  </el-checkbox>
                </el-form-item>
                <el-form-item prop="editFormRef">
                  <el-checkbox v-model="formData.editFormRef" @change="freshForm">
                    同步修改表单引用名称(为当前名称拼音)
                  </el-checkbox>
                </el-form-item> -->
              </el-form>
            </div>
          </div>
          <template #footer>
            <span class="dialog-footer">
              <el-button @click="closeDialog">取消</el-button>
              <el-button :loading="formDataLoding" @click="updateForm('updateForm')">保存</el-button>
              <el-button type="primary" :loading="formDataLoding"
                         @click="updateForm('updateForm', complete(formData['#info'].id))"
              >编辑表单</el-button>
            </span>
          </template>
        </el-dialog>

        <el-dialog
          top="5vh"
          custom-class="dialog-visible ability_detail"
          :title="dialogInfo.title"
          destroy-on-close
          :visible.sync="showCopyDialog"
        >
          <div slot="title">
            <span>{{ dialogInfo.title }}</span>
          </div>
          <div style="height: 300px;">
            <div class="mod-condition">
              <div class="_title clearfix">
                <span />
                <label>{{ dialogInfo.formTitle }}</label>
              </div>
              <el-form :key="fresh"
                       ref="updateForm"
                       v-loading="formDataLoding" :model="formData" class="demo-form-inline"
                       style="width: 85%;height: 180px;"
                       label-width="30%"
                       size="mini"
                       :rules="newFormRules"
              >
                <el-form-item label="表单名称" style="margin-top: 12%;" prop="name" maxlength="40">
                  <el-input v-model="formData.name" placeholder="请输入表单名称" />
                  <span style="position: absolute; right: 10px; bottom: 0; font-size: 10px; opacity: 0.6">
                    {{ formNameMaxLenth(formData.name, 40) }}
                  </span>
                </el-form-item>
                <!-- <el-form-item prop="editFormTitle">
                  <el-checkbox v-model="formData.editFormTitle" @change="freshForm">
                    同步修改表单标题(与当前名称相同)
                  </el-checkbox>
                </el-form-item>
                <el-form-item prop="editFormModel">
                  <el-checkbox v-model="formData.editFormModel" @change="freshForm">
                    同步修改数据模型(为当前名称拼音)
                  </el-checkbox>
                </el-form-item>
                <el-form-item prop="editFormRef">
                  <el-checkbox v-model="formData.editFormRef" @change="freshForm">
                    同步修改表单引用名称(为当前名称拼音)
                  </el-checkbox>
                </el-form-item> -->
              </el-form>
            </div>
          </div>
          <template #footer>
            <span class="dialog-footer">
              <el-button @click="closeDialog">取消</el-button>
              <el-button id="updateSubmitButton" :loading="formDataLoding" type="primary">
                {{ dialogInfo.submitButtonTitle }}
              </el-button>
            </span>
          </template>
        </el-dialog>
        <el-dialog
          top="5vh"
          custom-class="dialog-visible ability_detail"
          title="表单数据查看"
          destroy-on-close
          :visible.sync="showDataDialog"
        >
          <div slot="title">
            <span>表单数据查看</span>
          </div>
          <div class="mod-result-table">
            <div class="_title clearfix">
              <div class="f-l">
                <span />
                <label>表单数据列表</label>
                <p>共有<span>{{ dataTable.tableTotalSize }}</span>条查询结果</p>
              </div>
              <div class="f-r">
                <button class="mod-btn-mini mod-btn-first">
                  刷新
                </button>
                <input
                  v-model="dataTable.search"
                  size="mini"
                  placeholder="根据标签名称搜索"
                >
              </div>
            </div>
            <el-table
              :data="dataTable.resultTableData"
              style="width: 100%"
              border="border"
              stripe
            >
              <el-table-column
                prop="#info.id"
                label="表单项ID"
                align="center"
              />
              <el-table-column
                prop="label"
                label="标签名称"
                align="center"
              />
              <el-table-column
                prop="model"
                align="center"
                label="绑定模型"
              />
              <el-table-column
                prop="value"
                align="center"
                label="值"
              >
                <template slot-scope="scope">
                  <span v-show="!scope.row.edit">{{ scope.row.value }}</span>
                  <el-input v-show="scope.row.edit" v-model="scope.row.value" size="mini" />
                </template>
              </el-table-column>
              <el-table-column
                fixed="right"
                label="操作"
                align="center"
                width="130"
              >
                <template slot-scope="scope">
                  <el-button v-if="scope.row.edit" type="text" style="border: none;" @click="keepDataColumn(scope.row)">
                    保存
                  </el-button>
                  <el-button v-if="scope.row.edit" type="text" style="border: none;"
                             @click="stopEditDataColumn(scope.row)"
                  >
                    关闭
                  </el-button>
                  <el-button v-else type="text" style="border: none;" @click="editDataColumn(scope.row)">
                    编辑
                  </el-button>
                </template>
              </el-table-column>
            </el-table>
            <el-pagination
              class="mod-pagination"
              popper-class="mod-pagination-select"
              :current-page.sync="dataTable.currentPage"
              :page-sizes="[10, 20, 50, 100]"
              :page-size="dataTable.pageSize"
              layout="prev,  pager, next,slot,total, sizes "
              :total="dataTable.pageTotal"
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
            >
              <span class="txt">到第</span>
              <input v-model="dataTable.toPage" class="input-txt" type="text">
              <span class="txt">页</span>
              <button class="btn" @click="handleCurrentClick">
                确定
              </button>
            </el-pagination>
          </div>
          <template #footer>
            <span class="dialog-footer">
              <el-button type="primary" @click="closeDialog">关闭</el-button>
            </span>
          </template>
        </el-dialog>
      </el-main>
      <!-- <el-footer>Footer</el-footer> -->
    </el-container>
  </div>
</template>

<script>
import Pinyin from 'js-pinyin'
import { formConf } from '@/components/generator/config.js'
import { deepClone } from '@/utils/index'

export default {
  name: 'CtManageForm',
  components: {
  },
  props: {
  },
  data () {
    return {
      fresh: true,
      criteria: {
        name: ''
      },
      formData: {
        name: '',
        editFormTitle: true,
        editFormModel: true,
        editFormRef: true,
        '#info': {
          id: ''
        }
      },
      formConf,
      resultTableData: [{}],
      tableTotalSize: 0,
      currentPage: 1,
      toPage: 1,
      pageSize: 20,
      showAddNewDialog: false,
      showEditDialog: false,
      showCopyDialog: false,
      showDataDialog: false,
      formDataLoding: false,
      step: 0,
      newFormRules: {
        name: [
          { required: true, message: '表单名称不可为空', trigger: 'blur' },
          { validator: this.validFormName, trigger: 'blur' }
        ]
      },
      dataTable: {
        resultTableData: [{}],
        tableTotalSize: 0,
        currentPage: 1,
        toPage: 1,
        pageSize: 20,
        search: ''
      },
      dialogInfo: {
        title: '复制表单',
        formTitle: '复制表单页面',
        submitButtonTitle: '复制'
      }
    }
  },
  computed: {
  },
  watch: {
  },
  mounted () {
    this.initManageTable()
  },
  methods: {
    freshForm () {
      this.fresh = false
      this.fresh = true
    },
    onSearch () {
      this.initManageTable(this.criteria)
    },
    onReset () {
      this.criteria.name = ''
    },
    onAddNew () {
      this.step = 0
      this.formData.name = ''
      this.showAddNewDialog = true
    },
    onDelete (index, data) {
      this.$confirm(`确定要删除表单${data.name}吗？`, '提示', { type: 'warning' }).then(
        () => {
          this.formDataLoding = true
          this.$formEnginesAxios({
            method: 'delete',
            url: '/delete',
            params: {
              formId: data['#info'].id
            }
          }).then(resp => {
            // 数据处理
            this.formDataLoding = false
            const respData = resp.data
            if (respData.resultStat !== '000') {
              this.$message.error('删除表单失败,服务内部错误')
              console.log('删除表单失败,服务内部错误', respData)
              return
            }
            this.$message.success('删除表单成功')
            this.initManageTable(this.criteria)
          }, err => {
            this.formDataLoding = false
            console.log('删除表单失败,请检查网络/服务状态', err)
            this.$message.error('删除表单失败,请检查网络/服务状态')
          })
        }
      ).catch(() => {
        this.formDataLoding = false
      })
    },
    onEdit (index, data) {
      this.initEditForm(data['#info'].id)
      this.formData.editFormTitle = true
      this.formData.editFormModel = true
      this.formData.editFormRef = true
      this.showEditDialog = true
    },
    onCopy (index, data) {
      this.initEditForm(data['#info'].id)
      this.formData.editFormTitle = true
      this.formData.editFormModel = true
      this.formData.editFormRef = true
      const dialogInfo = {
        title: '复制表单',
        formTitle: '复制表单页面',
        submitButtonTitle: '复制'
      }
      this.dialogInfo = dialogInfo
      this.showCopyDialog = true

      const btn = document.getElementById('updateSubmitButton')
      btn.addEventListener('click', () => {
        this.copyForm('updateForm', this.formData['#info'].id)
      })
    },
    onRebuild (index, data) {
      this.initEditForm(data['#info'].id)
      this.formData.editFormTitle = true
      this.formData.editFormModel = true
      this.formData.editFormRef = true
      const dialogInfo = {
        title: '重建表单',
        formTitle: '重建表单页面',
        submitButtonTitle: '重建'
      }
      this.dialogInfo = dialogInfo
      this.showCopyDialog = true
      const btn = document.getElementById('updateSubmitButton')
      btn.addEventListener('click', () => {
        this.rebuildForm('updateForm', this.formData['#info'].id)
      })
    },
    onData (index, data) {
      this.initDataTable(data['#info'].id)
      this.showDataDialog = true
    },
    initEditForm (uuid) {
      this.formDataLoding = true
      // TODO: 获取保存的表json
      this.$formEnginesAxios({
        method: 'get',
        url: '/get',
        params: {
          formId: uuid
        }
      }).then(resp => {
        // 数据处理
        const respData = resp.data
        this.formDataLoding = false
        if (respData.resultStat !== '000') {
          this.$message.error('获取表单失败,服务内部错误')
          console.log('获取表单失败,服务内部错误', respData)
          return
        }
        this.formData = respData.data
      }, err => {
        console.log('获取表单失败,请检查网络/服务状态', err)
        this.$message.error('获取表单失败,请检查网络/服务状态')
        this.formData = {}
        this.formDataLoding = false
      })
    },
    initDataTable (uuid) {
      this.$formEnginesAxios({
        method: 'get',
        url: `/data/select/list/${uuid}`
      }).then(resp => {
        // 数据处理
        const respData = resp.data
        if (respData.resultStat !== '000') {
          this.$message.error('获取表单失败,服务内部错误')
          console.log('获取表单失败,服务内部错误', respData)
          return
        }
        const formData = respData.data
        this.$formEnginesAxios({
          method: 'get',
          url: '/get',
          params: {
            formId: uuid
          }
        }).then(resp2 => {
          // 数据处理
          const respData2 = resp2.data
          this.formDataLoding = false
          if (respData2.resultStat !== '000') {
            this.$message.error('获取表单失败,服务内部错误')
            console.log('获取表单失败,服务内部错误', respData2)
            return
          }
          const formData2 = respData2.data
          formData.forEach(data => {
            Object.keys(data).forEach(key => {
              const item = this.getItemObject(key, data[key], formData2)
              this.dataTable.resultTableData.push(item)
            })
          })
        }, err => {
          this.formDataLoding = false
          console.log('获取表单失败,请检查网络/服务状态', err)
          this.$message.error('获取表单失败,请检查网络/服务状态')
        })
        this.formDataLoding = false
      }, err => {
        console.log('获取表单失败,请检查网络/服务状态', err)
        this.$message.error('获取表单失败,请检查网络/服务状态')
        this.formDataLoding = false
      })
    },
    getItemObject (key, value, formList) {
      const item = {
        '#info': '',
        label: '',
        model: '',
        value
      }
      formList.fields.forEach(field => {
        if (field.tableColumn === key) {
          item['#info'] = field['#info']
          item.label = field.__config__.label
          item.model = field.__vModel__
        }
      })
      return item
    },
    // 切换每页显示条数时
    handleSizeChange (val) {
      this.pageSize = val
      this.getFormList(this.criteria)
    },
    // 点击页码时
    handleCurrentChange (val) {
      this.toPage = val
      this.currentPage = val
      this.getFormList(this.criteria)
    },
    // 点击‘确定’按钮时
    handleCurrentClick (toPage) {
      // 判断输入的是否为正整数
      if ((/(^[1-9]\d*$)/.test(toPage))) {
        const maxPageNum = Math.ceil(this.pageTotal / this.pageSize)
        if (toPage > maxPageNum) {
          this.currentPage = maxPageNum
          toPage = maxPageNum
        } else {
          this.currentPage = parseFloat(toPage)
        }
        this.getFormList(this.criteria)
      } else {
        // 当用户输入非正整数时，若要回到第一页，则放开下面两行代码
        // this.currentPageValue = 1
        // this.currentPage = 1
        console.log('error')
        // 代码逻辑
      }
    },
    closeDialog () {
      this.showAddNewDialog = false
      this.showEditDialog = false
      this.showCopyDialog = false
      this.showDataDialog = false
      this.initManageTable(this.criteria)
    },
    complete (uuid) {
      this.showAddNewDialog = false
      this.showEditDialog = false
      this.$router.push({ name: 'form_engines_edit', params: { uuid } })
    },
    // 初始化管理表格
    initManageTable (criteria) {
      // 获取表单列表
      this.getFormList(criteria)
    },
    getFormList (criteria) {
      this.$formEnginesAxios({
        method: 'get',
        url: '/page',
        params: { name: criteria?.name, currentPage: this.currentPage, pageSize: this.pageSize }
      }).then(resp => {
        // 数据处理
        const respData = resp.data
        if (respData.resultStat !== '000') {
          this.$message.error('获取表单列表失败,服务内部错误')
          console.log('获取表单列表失败,服务内部错误', respData)
          return
        }
        this.resultTableData = respData.data.list
        this.tableTotalSize = respData.data.total
      }, err => {
        console.log('获取表单列表失败,请检查网络/服务状态', err)
        this.$message.error('获取表单列表失败,请检查网络/服务状态')
      })
    },
    formNameMaxLenth (name, length) {
      if (typeof (name) !== 'string') {
        name = ''
      }
      let current = this.getFormNameLength(deepClone(name))
      while (current > length) {
        name = name.slice(0, -1)
        current = this.getFormNameLength(deepClone(name))
      }
      this.formData.name = name
      return `${current}/${length}`
    },
    getFormNameLength (name) {
      name = Pinyin.getFullChars(name)
      return name.length
    },
    addNewForm (formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.formDataLoding = true
          this.formConf.name = this.formData.name
          this.formConf.formName = Pinyin.getFullChars(this.formData.name) // 建表用拼音字段，表单业务名称为name字段
          this.formConf.formTitle = this.formData.name
          this.formConf.formRef = Pinyin.getFullChars(this.formData.name)
          this.formConf.formModel = Pinyin.getFullChars(this.formData.name)
          this.formConf.fields = []
          this.$formEnginesAxios({
            method: 'post',
            url: '/add',
            data: { ...this.formConf }
          }).then(resp => {
            // 数据处理
            const respData = resp.data
            this.formDataLoding = false
            if (respData.resultStat !== '000') {
              this.$message.error('创建表单失败,服务内部错误')
              console.log('创建表单失败,服务内部错误', respData)
              return
            }
            this.formData['#info'] = {}
            this.formData['#info'].id = respData.data
            this.step++
          }, err => {
            this.formDataLoding = false
            console.log('创建表单失败,请检查网络/服务状态', err)
            this.$message.error('创建表单失败,请检查网络/服务状态')
          })
        } else {
          console.log('表单格式校验失败')
        }
      })
    },
    updateForm (formName, callback) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.formDataLoding = true
          this.formData.formName = Pinyin.getFullChars(this.formData.name)
          if (this.formData.editFormTitle) {
            this.formData.formTitle = this.formData.name
          }
          if (this.formData.editFormRef) {
            this.formData.formRef = Pinyin.getFullChars(this.formData.name)
          }
          if (this.formData.editFormModel) {
            this.formData.formModel = Pinyin.getFullChars(this.formData.name)
          }
          this.$formEnginesAxios({
            method: 'patch',
            url: '/update',
            data: { ...this.formData }
          }).then(resp => {
            // 数据处理
            const respData = resp.data
            this.formDataLoding = false
            if (respData.resultStat !== '000') {
              this.$message.error('创建表单失败,服务内部错误')
              console.log('创建表单失败,服务内部错误', respData)
              return
            }
            this.closeDialog()
            if (callback) {
              callback()
            }
            this.$message.success('保存成功')
          }, err => {
            this.formDataLoding = false
            console.log('创建表单失败,请检查网络/服务状态', err)
            this.$message.error('创建表单失败,请检查网络/服务状态')
          })
        } else {
          console.log('表单格式校验失败')
        }
      })
    },
    copyForm (formName, uuid) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.formDataLoding = true
          this.$formEnginesAxios({
            method: 'post',
            url: '/addBaseOnFormModel',
            params: {
              formId: uuid,
              name: this.formData.name
            }
          }).then(resp => {
            // 数据处理
            const respData = resp.data
            this.formDataLoding = false
            if (respData.resultStat !== '000') {
              this.$message.error('复制表单失败,服务内部错误')
              console.log('复制表单失败,服务内部错误', respData)
              return
            }
            this.$message.success('复制表单成功')
            this.closeDialog()
          }, err => {
            this.formDataLoding = false
            console.log('复制表单失败,请检查网络/服务状态', err)
            this.$message.error('复制表单失败,请检查网络/服务状态')
          })
        } else {
          console.log('表单格式校验失败')
        }
      })
    },
    rebuildForm (formName, uuid) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.formDataLoding = true
          this.$formEnginesAxios({
            method: 'post',
            url: '/rebuild',
            params: {
              formId: uuid,
              name: this.formData.name
            }
          }).then(resp => {
            // 数据处理
            const respData = resp.data
            this.formDataLoding = false
            if (respData.resultStat !== '000') {
              this.$message.error('重建表单失败,服务内部错误')
              console.log('重建表单失败,服务内部错误', respData)
              return
            }
            this.$message.success('重建表单成功')
            this.closeDialog()
          }, err => {
            this.formDataLoding = false
            console.log('重建表单失败,请检查网络/服务状态', err)
            this.$message.error('重建表单失败,请检查网络/服务状态')
          })
        } else {
          console.log('表单格式校验失败')
        }
      })
    },
    changeDisabledStatus (row, status) {
      const type = status === 1 ? '禁用' : '启用'
      this.$confirm(`确定要${type}表单${row.name}吗？`, '提示', { type: 'warning' }).then(
        () => {
          this.formDataLoding = true
          this.$formEnginesAxios({
            method: 'post',
            url: '/changeDisabledStatus',
            params: {
              formId: row['#info'].id,
              disabled: status === 1
            }
          }).then(resp => {
            // 数据处理
            this.formDataLoding = false
            const respData = resp.data
            if (respData.resultStat !== '000') {
              this.$message.error(`${type}表单失败,服务内部错误`)
              console.log(`${type}表单失败,服务内部错误`, respData)
              return
            }
            this.$message.success(`${type}表单成功`)
            this.initManageTable(this.criteria)
          }, err => {
            this.formDataLoding = false
            console.log(`${type}表单失败,请检查网络/服务状态`, err)
            this.$message.error(`${type}表单失败,请检查网络/服务状态`)
          })
        }
      )
    },
    validFormName (rule, value, callback) {
      const reg = /^[^0-9_][0-9a-zA-Z\u4e00-\u9fa5_]+[^_]$/
      if (reg.test(value)) {
        callback()
      } else {
        callback(new Error('只能由中文,字母,数字和下划线`_`组成。 不能以数字,下划线开头;不能以下划线结尾'))
      }
    },
    editDataColumn (row) {
      this.dataTable.resultTableData.forEach(data => {
        if (row['#info'].id === data['#info'].id) {
          data.edit = true
        }
      })
    },
    stopEditDataColumn (row) {
      this.dataTable.resultTableData.forEach(data => {
        if (row['#info'].id === data['#info'].id) {
          data.edit = false
        }
      })
    },
    keepDataColumn (row) {
      const keep = row
      this.$formEnginesAxios({
        method: 'patch',
        url: '/data/update',
        data: { ...keep }
      }).then(resp => {
        // 数据处理
        const respData = resp.data
        if (respData.resultStat !== '000') {
          this.$message.error('创建表单失败,服务内部错误')
          console.log('创建表单失败,服务内部错误', respData)
          return
        }
        this.formDataLoding = false
        this.$message.success('保存成功')
      }, err => {
        this.formDataLoding = false
        console.log('创建表单失败,请检查网络/服务状态', err)
        this.$message.error('创建表单失败,请检查网络/服务状态')
      })
    }

  }
}
</script>

<style scoped>
.link {
  color: #eb4b4b;
}
.disabledLink{
  pointer-events: none;
  cursor: default;
  color: gainsboro;
}
.disabledButton{
  color: gainsboro !important;
}
</style>
