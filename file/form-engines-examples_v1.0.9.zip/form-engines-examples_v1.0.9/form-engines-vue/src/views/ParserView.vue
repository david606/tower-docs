<template>
  <div class="parser">
    <ct-parser @beforeLoad="beforeLoadHandler"
               @afterLoad="afterLoadHandler"
               @beforeSubmit="beforeSubmitHandler"
               @afterSubmit="afterSubmitHandler"
               :fieldEvents="fieldEvents"
              ref="ct-parser"
              :uuid="uuid"
              :defaultSubmitTips="defaultSubmitTips">
    </ct-parser>
    <div style="text-align: center;">
      <ct-button @click="submitType1" type="primary">提交</ct-button>
      <ct-button @click="resetForm" type="">重置</ct-button>
    </div>
    <div style="text-align: center;">
      <ct-button @click="getFormRef" type="">拿表单ref</ct-button>
      <ct-button @click="getFormModel" type="">拿表单数据</ct-button>
      <ct-button @click="fillFormData" type="">填充默认数据</ct-button>
    </div>

  </div>
</template>
<script>
export default {
  name: 'ParserView',
  components: {
  },
  props: {
    // 表单的uuid
    uuid: {
      type: String,
      default: () => ''
    },
    // 默认提交数据到表单引擎数据表内，@submit事件触发
    defaultSubmit: {
      type: Boolean,
      default: () => true
    },
    // 展示默认提交后的提示信息
    defaultSubmitTips: {
      type: Boolean,
      default: () => true
    }
  },

  data () {
    return {
      formValuesData: {},
      fieldEvents: {
        DanXingWenBen101: {
          blur: event => {
            console.log(`'DanXingWenBen101 blur 事件被触发: '${JSON.stringify(event)}', e.target.value: '${event.target.value}`)
          }
        },
        XiaLaXuanZe116: {
          change: event => {
            console.log(`'XiaLaXuanZe116 change 事件被触发: '${JSON.stringify(event)}`)
          }
        }
      }
    }
  },

  mounted () {
    // this.fillFormData()
    // this.initEditForm()
  },
  methods: {
    beforeLoadHandler (data) {
      console.log(`'触发了beforeLoad事件处理函数: '${JSON.stringify(data)}`)
    },
    afterLoadHandler (data) {
      console.log(`'触发了afterLoad事件处理函数: '${JSON.stringify(data)}`)
      // this.initEditForm()
    },
    beforeSubmitHandler (data) {
      const obj2 = this.$refs['ct-parser'].getFormEl('DanXingWenBen101')
      console.log(`'触发了beforeSubmit事件处理函数: '${JSON.stringify(data)}, obj2: ${obj2}`)
    },
    afterSubmitHandler (data) {
      const obj1 = this.$refs['ct-parser'].getFormItem('DanXingWenBen101')
      const obj2 = this.$refs['ct-parser'].getFormEl('DanXingWenBen101')
      obj2.focus()
      console.log(`'触发了afterSubmit事件处理函数: '${JSON.stringify(data)}, obj1: ${obj1}, obj2: ${obj2}`)
    },
    resetForm () {
      // 重置表单
      this.$refs['ct-parser'].resetForm()
    },
    async validForm () {
      // 校验表单，返回校验值true/false
      const valid = await this.$refs['ct-parser'].validForm()
      return valid
    },
    submitType1 () {
      // 使用校验函数，通过返回值执行自己的业务
      if (this.validForm()) {
        this.mySubmit()
      }
    },
    submitType2 () {
      // 直接传入回调函数，校验成功，自动执行回调函数
      this.$refs['ct-parser'].validForm(this.mySubmit)
    },
    mySubmit () {
      // 提交时处理的业务
      console.log('mySubmit', this.getFormModel())
    },
    getFormModel () {
      // 获取表单的数据
      const formModel = this.$refs['ct-parser'].getFormModel()
      console.log(formModel)
      return formModel
    },
    getFormRef () {
      // 保底方法，返回表单的ref。 注意该模型为el-form，支持el-form的所有默认方法
      const formRef = this.$refs['ct-parser'].getFormRef()
      console.log(formRef)
    },
    fillFormData () {
      // const data = { XingBie101: '女', JiLianKuoZhanCeShi102: 'value2' }

      // 填充默认数据
      // const data = { ...this.getFormModel() }
      // console.log('-----data: ' + JSON.stringify(data) + ', ' + JSON.stringify({ ...this.getFormModel() }))
      // Object.keys(data).forEach(key => {
      //   if (typeof (data[key]) === 'string' || data[key] === undefined) {
      //     data[key] = '默认数据'
      //   }
      //   if (typeof (data[key]) === typeof ([])) {
      //     data[key] = [1, 2]
      //   }
      //   if (typeof (data[key]) === 'number') {
      //     data[key] = 1
      //   }
      // })
      // const data = this.formValuesData
      // console.log('-----data: ' + JSON.stringify(data))
      const data = { DanXingWenBen101: '哈哈哈哈哈', JiShuQi102: 10 }
      this.$refs['ct-parser'].fillFormData(data)
    },
    // 请求服务端获取表单数据并填充到表单页面
    initEditForm () {
      this.$formEnginesAxios({
        method: 'get',
        url: '/data/get',
        params: {
          formId: this.uuid,
          id: 'a9db01ac1cb911efb44d00163e0101c9'
        }
      }).then(resp => {
        // 数据处理
        const respData = resp
        // console.log(JSON.stringify(resp))
        if (respData.resultStat !== '000') {
          this.$message.error('获取表单失败,服务内部错误')
          console.log('获取表单失败,服务内部错误', respData)
          return
        }
        console.log(JSON.stringify(respData.data.extendProperty))
        this.$refs['ct-parser'].fillFormData(respData.data.extendProperty)
      }, err => {
        console.log('获取表单失败,请检查网络/服务状态', err)
        this.$message.error('获取表单失败,请检查网络/服务状态')
        this.formValuesData = {}
      })
    }
  }
}

</script>
