import Vue from 'vue'
import VueRouter from 'vue-router'
import HomeView from '../views/HomeView.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'form_engines_manage',
    component: HomeView
  },
  // {
  //   path: '/',
  //   name: 'form_engines_manage',
  //   component: () => import('../views/ManageView.vue') // 管理页面源码
  // },
  {
    path: '/edit/:uuid',
    name: 'form_engines_edit', // 页面由manage跳到edit使用了根据name跳转，因此若使用默认的ct-form-manage,此处name应填写form_engines_edit
    component: () => import('../views/EditView.vue'),
    props: true
  },
  {
    path: '/ct-parser/:uuid',
    name: 'form_engines_parser', // 页面由manage跳到parser使用了根据name跳转，因此若使用默认的ct-form-manage,此处name应填写form_engines_parser
    component: () => import('../views/ParserView.vue'),
    props: true
  }
]

const router = new VueRouter({
  routes
})

export default router
