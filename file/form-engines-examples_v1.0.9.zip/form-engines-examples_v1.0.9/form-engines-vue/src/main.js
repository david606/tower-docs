import Vue from 'vue'
import App from './App.vue'
import router from './router'
import ChinaTowerUI from '@ct/china-tower-ui'
import ElementUI from 'element-ui'
import FormEngine from '@ct/china-tower-form-engine'

Vue.use(ElementUI)
Vue.use(ChinaTowerUI)

Vue.use(FormEngine)

Vue.config.productionTip = false

const store = FormEngine.store

// Vue.prototype.$formEnginesAxios = Axios.create({
//   // 设置baseURL为'/api/v1beta1'
//   baseURL: '/form-engines'
// })

// Vue.prototype.$formEnginesAxios.interceptors.request.use(function (config) {
//   // 在发送请求之前做些什么
//   console.log('请求拦截器被触发', config)
//   config.headers.token = 'Token 202308221030583455'
//   return config
// }, function (error) {
//   // 对请求错误做些什么
//   return Promise.reject(error)
// })

// Vue.prototype.$formEnginesAxios.interceptors.response.use(
//   response => {
//     // 对返回的response进行处理，返回response.data
//     return response
//   },
//   error => {
//     // 对返回的错误error进行处理，返回一个被拒绝的Promise
//     return Promise.reject(error)
//   }
// )

new Vue({
  store,
  router,
  render: h => h(App)
}).$mount('#app')
