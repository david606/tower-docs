const { defineConfig } = require('@vue/cli-service')
const CopyWebpackPlugin = require('copy-webpack-plugin')

module.exports = defineConfig({
  transpileDependencies: true
})

module.exports = {
  devServer: {
    open: false, // 是否自动启动浏览器
    host: '0.0.0.0',
    port: 8082,
    proxy: {
      '/form-engines': {
        // target: 'http://127.0.0.1:19998', // 代理服务器地址
        target: 'http://10.180.22.69:19998', // 代理服务器地址
        changeOrigin: true, // 是否跨域
        logLevel: 'debug'
      }
    }
  },
  productionSourceMap: false,
  configureWebpack: {
    resolve: {
      alias: {
        Vue: 'vue',
        VueRouter: 'vue-router',
        ELEMENT: 'element-ui'
      }
    },
    plugins: [
      new CopyWebpackPlugin({
        patterns: [
          {
            from: 'node_modules/@ct/china-tower-form-engine/dist/img',
            to: 'js/img',
            toType: 'dir'
          },
          {
            from: 'node_modules/@ct/china-tower-form-engine/dist/static/',
            to: 'static/',
            toType: 'dir'
          }
        ],
        options: {
          // 可选配置项
        }
      })
    ]
  }
}
