/*
 Navicat Premium Data Transfer

 Source Server         : 22.5
 Source Server Type    : MySQL
 Source Server Version : 50721 (5.7.21-log)
 Source Host           : 10.180.22.5:3306
 Source Schema         : form_engine

 Target Server Type    : MySQL
 Target Server Version : 50721 (5.7.21-log)
 File Encoding         : 65001

 Date: 07/08/2023 17:15:36
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for jszt_dict_data
-- ----------------------------
DROP TABLE IF EXISTS `jszt_dict_data`;
CREATE TABLE `jszt_dict_data` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '字典编码',
  `sort` int(4) DEFAULT '0' COMMENT '字典排序',
  `option_label` varchar(100) DEFAULT '' COMMENT '字典标签',
  `option_value` varchar(100) DEFAULT '' COMMENT '字典键值',
  `type` varchar(100) DEFAULT '' COMMENT '字典类型',
  `is_default` tinyint(4) DEFAULT '0' COMMENT '是否默认（1是 0否 ）',
  `status` tinyint(4) DEFAULT '1' COMMENT '状态（1正常 0停用）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  KEY `dict_data_type_IDX` (`type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 COMMENT='字典数据表';

-- ----------------------------
-- Table structure for jszt_dict_type
-- ----------------------------
DROP TABLE IF EXISTS `jszt_dict_type`;
CREATE TABLE `jszt_dict_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '字典主键',
  `name` varchar(100) DEFAULT '' COMMENT '字典名称',
  `type` varchar(100) DEFAULT '' COMMENT '字典类型',
  `status` tinyint(4) DEFAULT '1' COMMENT '状态（1正常 0停用）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `dict_type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COMMENT='字典类型表';

-- ----------------------------
-- Table structure for jszt_form
-- ----------------------------
DROP TABLE IF EXISTS `jszt_form`;
CREATE TABLE `jszt_form` (
  `id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_estonian_ci NOT NULL COMMENT '主键',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_estonian_ci NOT NULL COMMENT '表单名称(业务)',
  `table_name` varchar(255) NOT NULL COMMENT '数据表名称',
  `table_column_size` int(11) NOT NULL DEFAULT '0' COMMENT '数据表行容量',
  `disabled` tinyint(2) NOT NULL DEFAULT '0' COMMENT '1禁用，0正常',
  `valid` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1有效, 0无效',
  `parent_id` varchar(32) DEFAULT NULL COMMENT '父模型id',
  `rebuild_from` varchar(32) DEFAULT NULL COMMENT '重建基于的模型id',
  `update_time` datetime NOT NULL COMMENT '修改时间',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `extend_property` json NOT NULL COMMENT '完整配置',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='表单管理表';

-- ----------------------------
-- Table structure for jszt_form_item
-- ----------------------------
DROP TABLE IF EXISTS `jszt_form_item`;
CREATE TABLE `jszt_form_item` (
  `id` varchar(32) NOT NULL COMMENT '主键',
  `form_id` varchar(32) NOT NULL COMMENT '表单ID',
  `table_column` varchar(64) DEFAULT NULL COMMENT '数据表列名',
  `column_size` int(11) DEFAULT '32' COMMENT '大于0 varchar(长度),  -1 decimal, -2 bigint',
  `type` varchar(32) NOT NULL COMMENT '类型',
  `label` varchar(32) DEFAULT NULL COMMENT '字段标签',
  `sort` int(11) NOT NULL COMMENT '排序',
  `flag` varchar(32) NOT NULL DEFAULT 'common-item' COMMENT '业务字段 common-item，行容器 inline-container，行内字段 inline-item',
  `required` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1必填, 0无需',
  `disabled` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1禁用, 0正常',
  `valid` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1有效, 0无效',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `update_time` datetime NOT NULL COMMENT '修改时间',
  `extend_property` json NOT NULL COMMENT '完整属性',
  `container_id` varchar(32) DEFAULT NULL COMMENT '行容器id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='表单项表';

SET FOREIGN_KEY_CHECKS = 1;
