package com.chinatower.cloud.examples.form.controller;

import com.chinatower.cloud.starter.form.engine.external.FormCascadeItemData;
import com.chinatower.cloud.starter.form.engine.external.builder.ExternalItemCreator;
import com.chinatower.cloud.starter.form.engine.external.builder.ExternalSelectItemParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import java.util.ArrayList;
import java.util.List;

public class TestCascadeFormEnginesExtends implements ExternalItemCreator {

    @Autowired
    private Environment environment;
    @Override
    public ExternalSelectItemParam create() {

        ExternalSelectItemParam param=new ExternalSelectItemParam();
        param.setName("级联扩展测试");
        param.setCascade(true);
        List<FormCascadeItemData> dataList=new ArrayList<>();
        dataList.add(new FormCascadeItemData("value1","0",true,"0"));
        dataList.add(new FormCascadeItemData("value2","1",false,"1"));
        dataList.add(new FormCascadeItemData("value3","2",false,"2"));
        param.setDataList(dataList);
        return param;
    }

}
