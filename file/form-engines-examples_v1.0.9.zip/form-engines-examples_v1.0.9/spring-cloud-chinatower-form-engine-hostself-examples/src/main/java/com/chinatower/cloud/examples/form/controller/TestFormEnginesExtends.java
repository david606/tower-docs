package com.chinatower.cloud.examples.form.controller;

import com.chinatower.cloud.starter.form.engine.external.FormItemData;
import com.chinatower.cloud.starter.form.engine.external.builder.ExternalItemCreator;
import com.chinatower.cloud.starter.form.engine.external.builder.ExternalSelectItemParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import java.util.ArrayList;
import java.util.List;

public class TestFormEnginesExtends implements ExternalItemCreator {

    @Autowired
    private Environment environment;
    @Override
    public ExternalSelectItemParam create() {

        System.out.println(environment.getActiveProfiles());
        ExternalSelectItemParam param=new ExternalSelectItemParam();
        param.setName("扩展测试");
        List<FormItemData> dataList=new ArrayList<>();
        dataList.add(new FormItemData("value1","0",true));
        dataList.add(new FormItemData("value2","1",false));
        dataList.add(new FormItemData("value3","2",false));
        param.setDataList(dataList);
        return param;
    }

}
