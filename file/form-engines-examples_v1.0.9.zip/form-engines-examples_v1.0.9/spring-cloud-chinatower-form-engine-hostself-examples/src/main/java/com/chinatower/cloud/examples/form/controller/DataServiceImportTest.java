//package com.chinatower.cloud.examples.form.controller;
//
//import com.chinatower.cloud.starter.form.engine.pojo.FormEntity;
//import com.chinatower.cloud.starter.form.engine.pojo.FormItemEntity;
//import com.chinatower.cloud.starter.form.engine.service.FormItemService;
//import com.chinatower.cloud.starter.form.engine.service.FormService;
//import com.chinatower.cloud.starter.form.engine.service.TableDataService;
//import com.chinatower.framework.common_service.response.RespResult;
//import com.github.pagehelper.PageInfo;
//import com.github.pagehelper.page.PageMethod;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.*;
//
//@RestController
//@RequestMapping("/test")
//public class DataServiceImportTest {
//
//
//    @Autowired
//    private FormService formService;
//
//    @Autowired
//    private FormItemService formItemService;
//
//    @Autowired
//    private TableDataService tableDataService;
//
//    @GetMapping("/data/page")
//    public RespResult dataSelectList(@RequestParam String formId, @RequestParam(defaultValue = "1") Integer currentPage,
//                                     @RequestParam(defaultValue = "20") Integer pageSize) {
//        FormEntity form = formService.getForm(formId);
//        if(form == null) {
//            return RespResult.FAIL("不存在此表单模型");
//        }
//        String tableName = form.getTableName();
//        ArrayList<String> tableColumns = new ArrayList<>();
//        for (FormItemEntity item : formItemService.listFormItem(formId)) {
//            tableColumns.add(item.getTableColumn());
//        }
//        PageMethod.startPage(currentPage, pageSize);
//        List<Map<String, Object>> result = tableDataService.selectAll(formId, tableName, tableColumns);
//        return RespResult.SUCCESS(new PageInfo<>(result));
//    }
//}
