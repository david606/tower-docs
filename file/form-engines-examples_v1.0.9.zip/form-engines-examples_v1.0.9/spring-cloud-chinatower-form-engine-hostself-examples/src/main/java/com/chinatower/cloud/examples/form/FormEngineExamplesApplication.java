package com.chinatower.cloud.examples.form;

import com.chinatower.cloud.starter.form.engine.external.EnableFormEngineExternal;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnableFormEngineExternal
//@ComponentScan(basePackages = {"com.chinatower.cloud.examples.form.*,com.chinatower.cloud.starter.form.*"})
public class FormEngineExamplesApplication {

    public static void main(String[] args) {
        SpringApplication.run(FormEngineExamplesApplication.class, args);
    }

}
