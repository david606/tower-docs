package com.longer.encrypt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EncryptDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
