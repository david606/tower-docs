package com.longer.encrypt;

import com.chinatower.encrypt.irreversible.MD5Util;
import com.chinatower.encrypt.irreversible.SHAUtil;
import com.chinatower.encrypt.irreversible.entity.MD5EncryptResult;
import com.chinatower.encrypt.irreversible.entity.SHAEncryptResult;
import com.chinatower.encrypt.sm4.SM4EncryptResult;
import com.chinatower.encrypt.sm4.SM4Util;
import com.chinatower.encrypt.symmetry.AESUtil;
import com.chinatower.encrypt.symmetry.DESedeUtil;
import com.chinatower.encrypt.symmetry.entity.AESEncryptResult;
import com.chinatower.encrypt.symmetry.entity.DESEncryptResult;
import com.chinatower.encrypt.unsymmetry.RSAUtil;
import com.chinatower.encrypt.unsymmetry.entity.RSADecryptResult;
import com.chinatower.encrypt.unsymmetry.entity.RSAEncryptResult;
import com.chinatower.encrypt.unsymmetry.entity.RSAKey;
import com.chinatower.encrypt.unsymmetry.entity.RSAKeyLevel;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RestController;

import java.security.SecureRandom;
import java.util.Objects;

/**
 * @Author: zlong
 * @Date: 2/4/2024 下午1:52
 * @Description: 加解密方法调用测试
 */
@RestController
public class EncryptDemo {
    //    @GetMapping("/encrypt")
    public static void main(String[] args) {
        String plainText = "最是人间留不住，朱颜辞镜花辞树！";
        System.out.println("1.1:" + sm4_hexString_true(plainText));
        System.out.println("1.2:" + sm4_hexString_false(plainText));
        System.out.println("2:" + encryptionMD5(plainText));
        System.out.println("3:" + encryptionMD5Valid(plainText, encryptionMD5(plainText).getData()));
        System.out.println("4:" + encryptionSHA1(plainText));
        System.out.println("5:" + encryptionSHA1Valid(plainText, encryptionSHA1(plainText).getData()));

        DESEncryptResult desEncryptResult = encryptionDESede(plainText);
        System.out.println("6:" + desEncryptResult);
        System.out.println("7:" + encryptionDESedeDecode(desEncryptResult.getKey(), desEncryptResult.getData(), null));

        AESEncryptResult aesEncryptResult = encryptionAES(plainText);
        System.out.println("8:" + aesEncryptResult);
        System.out.println("9:" + encryptionAESDecode(aesEncryptResult.getData(), aesEncryptResult.getKey(), null));

        RSAKey rsaKey = encryptionRSA(null);
        System.out.println("10:" + rsaKey);

        RSAEncryptResult encryptionRSAEncrypt = encryptionRSAEncrypt(plainText, rsaKey.getPublicKey(), rsaKey.getPrivateKey());
        System.out.println("11:" + encryptionRSAEncrypt);
        System.out.println("12:" + encryptionRSADecode(encryptionRSAEncrypt.getData(), rsaKey.getPublicKey(), encryptionRSAEncrypt.getSignData(), rsaKey.getPrivateKey()));
    }

    /**
     * SM4 加解密
     * secretKey 和 iv 为 16 进制的字符串(长度需为 32 位)
     *
     * @param plainText
     * @return
     */
    public static Object sm4_hexString_true(String plainText) {
        String secretKey = generateRandomHexString(32);
        String iv = generateRandomHexString(32);
        boolean hexString = true;
        // ECB 模式加解密
        SM4EncryptResult ecb_ming_rtn = SM4Util.encryptData_ECB(plainText, secretKey, hexString);
        SM4EncryptResult ecb_mi_rtn = SM4Util.decryptData_ECB(ecb_ming_rtn.getData(), secretKey, hexString);

        // CBC 模式加解密
        SM4EncryptResult cbc_ming_rtn = SM4Util.encryptData_CBC(plainText, secretKey, iv, hexString);
        SM4EncryptResult cbc_mi_rtn = SM4Util.decryptData_CBC(cbc_ming_rtn.getData(), secretKey, iv, hexString);
        return "ECB 模式加解密:\n" + ecb_ming_rtn + "\n" + ecb_mi_rtn + "\n" + "CBC 模式加解密:\n" + cbc_ming_rtn + "\n" + cbc_mi_rtn;
    }

    /**
     * SM4 加解密
     * secretKey 和 iv 为 16 位的随机字符串
     *
     * @param plainText
     * @return
     */
    public static Object sm4_hexString_false(String plainText) {
        String secretKey = generateRandomString(16);
        String iv = generateRandomString(16);
        boolean hexString = false;
        // ECB 模式加解密
        SM4EncryptResult ecb_ming_rtn = SM4Util.encryptData_ECB(plainText, secretKey, hexString);
        SM4EncryptResult ecb_mi_rtn = SM4Util.decryptData_ECB(ecb_ming_rtn.getData(), secretKey, hexString);

        // CBC 模式加解密
        SM4EncryptResult cbc_ming_rtn = SM4Util.encryptData_CBC(plainText, secretKey, iv, hexString);
        SM4EncryptResult cbc_mi_rtn = SM4Util.decryptData_CBC(cbc_ming_rtn.getData(), secretKey, iv, hexString);
        return "ECB 模式加解密:\n" + ecb_ming_rtn + "\n" + ecb_mi_rtn + "\n" + "CBC 模式加解密:\n" + cbc_ming_rtn + "\n" + cbc_mi_rtn;
    }

    /**
     * md5加密
     *
     * @param key 明文
     * @return 加密结果
     */
//    @GetMapping("/md5")
    public static MD5EncryptResult encryptionMD5(String key) {
        return MD5Util.encrypt(key);
    }

    /**
     * MD5校验
     *
     * @param key        明文
     * @param ciphertext 密文
     * @return 校验结果
     */
//    @GetMapping("/md5/valid")
    public static Object encryptionMD5Valid(String key, String ciphertext) {
        return MD5Util.valid(key, ciphertext);
    }

    /**
     * SHA1加密
     *
     * @param key 明文
     * @return 加密结果
     */
//    @GetMapping("/sha1")
    public static SHAEncryptResult encryptionSHA1(String key) {
        return SHAUtil.encrypt(key);
    }

    /**
     * SHA1加密校验
     *
     * @param key 明文
     * @return 加密结果
     */
//    @GetMapping("/sha1/valid")
    public static Object encryptionSHA1Valid(String key, String ciphertext) {
        return SHAUtil.valid(key, ciphertext);
    }

    /**
     * DESede加密
     *
     * @param key 明文
     * @return 加密结果
     */
//    @GetMapping("/DESede")
    public static DESEncryptResult encryptionDESede(String key) {
        return DESedeUtil.encrypt(key);
    }

    /**
     * DESede解密
     *
     * @param ciphertext 密文
     * @param key        密钥
     * @param offset     偏移量
     * @return 解密结果
     */
//    @GetMapping("/DESede/decode")
    public static Object encryptionDESedeDecode(String key, String ciphertext, String offset) {
        if (StringUtils.isEmpty(offset)) {
            return DESedeUtil.decrypt(ciphertext, key);
        }
        return DESedeUtil.decrypt(ciphertext, key, offset);
    }

    /**
     * AES加密
     *
     * @param key 明文
     * @return 加密结果
     */
//    @GetMapping("/AES")
    public static AESEncryptResult encryptionAES(String key) {
        return AESUtil.encrypt(key);
    }

    /**
     * AES解密
     *
     * @param key        密钥
     * @param ciphertext 密文
     * @return 解密结果
     */
//    @GetMapping("/AES/decode")
    public static Object encryptionAESDecode(String ciphertext, String key, String offset) {
        if (!StringUtils.isEmpty(offset)) {
            return AESUtil.decrypt(ciphertext, key, offset);
        }
        return AESUtil.decrypt(ciphertext, key);
    }

    /**
     * 获取RSA密钥
     *
     * @param level 密钥安全级别
     * @return 解密结果
     */
//    @PostMapping("/RSA")
    public static RSAKey encryptionRSA(RSAKeyLevel level) {
        if (!Objects.isNull(level)) {
            return RSAUtil.genKeyPair(level);
        }
        return RSAUtil.genKeyPair();
    }

    /**
     * RSA加密
     *
     * @param plainText  明文
     * @param publicKey  接收方公钥
     * @param privateKey 发送方私钥
     * @return 加密结果
     */
//    @GetMapping("/RSA/encrypt")
    public static RSAEncryptResult encryptionRSAEncrypt(String plainText, String publicKey, String privateKey) {
        return RSAUtil.encrypt(plainText, publicKey, privateKey);
    }

    /**
     * RSA解密
     *
     * @param ciphertext 密文
     * @param publicKey  接收方公钥
     * @param SignData   密文签名
     * @param privateKey 发送方私钥
     * @return 解密结果
     */
//    @GetMapping("/RSA/decode")
    public static RSADecryptResult encryptionRSADecode(String ciphertext, String publicKey, String SignData, String privateKey) {
        return RSAUtil.decrypt(ciphertext, privateKey, SignData, publicKey);
    }

    // utils

    /**
     * 生成一个给定长度的随机十六进制字符串
     *
     * @param length 随机字符串的长度
     * @return
     */
    public static String generateRandomHexString(int length) {
        StringBuilder hexStringBuilder = new StringBuilder();
        SecureRandom random = new SecureRandom();

        for (int i = 0; i < length; i++) {
            // 生成一个介于0-15之间的随机整数（对应十六进制的0-F）
            int randomNum = random.nextInt(16);
            // 将该随机整数转换为对应的十六进制字符并添加到字符串中
            hexStringBuilder.append(Integer.toHexString(randomNum).toUpperCase());
        }

        return hexStringBuilder.toString();
    }


    /**
     * 生成指定长度的随机字符串
     *
     * @param length
     * @return
     */
    public static String generateRandomString(int length) {
        String RANDOM_STRING_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        SecureRandom random = new SecureRandom();
        StringBuilder sb = new StringBuilder(length);

        for (int i = 0; i < length; i++) {
            int randomIndex = random.nextInt(RANDOM_STRING_CHARS.length());
            char randomChar = RANDOM_STRING_CHARS.charAt(randomIndex);
            sb.append(randomChar);
        }

        return sb.toString();
    }
}
