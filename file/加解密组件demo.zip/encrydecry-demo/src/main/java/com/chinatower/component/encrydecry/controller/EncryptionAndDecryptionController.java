package com.chinatower.component.encrydecry.controller;

import com.chinatower.encrypt.irreversible.MD5Util;
import com.chinatower.encrypt.irreversible.SHAUtil;
import com.chinatower.encrypt.symmetry.AESUtil;
import com.chinatower.encrypt.symmetry.DESedeUtil;
import com.chinatower.encrypt.unsymmetry.RSAUtil;
import com.chinatower.encrypt.unsymmetry.entity.RSAKeyLevel;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.Objects;


@RestController
@RequestMapping("/ed")
public class EncryptionAndDecryptionController {
    /**
     * md5加密
     * @param key 明文
     * @return 加密结果
     */
    @GetMapping("/md5")
    public Object encryptionMD5(String key) {
        return MD5Util.encrypt(key);
    }

    /**
     * MD5校验
     * @param key 明文
     * @param ciphertext 密文
     * @return 校验结果
     */
    @GetMapping("/md5/valid")
    public Object encryptionMD5Valid(String key,String ciphertext) {
        return MD5Util.valid(key,ciphertext);
    }

    /**
     * SHA1加密
     * @param key 明文
     * @return 加密结果
     */
    @GetMapping("/sha1")
    public Object encryptionSHA1(String key) {
        return SHAUtil.encrypt(key);
    }
    /**
     * SHA1加密校验
     * @param key 明文
     * @return 加密结果
     */
    @GetMapping("/sha1/valid")
    public Object encryptionSHA1Valid(String key,String ciphertext) {
        return SHAUtil.valid(key,ciphertext);
    }

    /**
     * DESede加密
     * @param key 明文
     * @return 加密结果
     */
    @GetMapping("/DESede")
    public Object encryptionDESede(String key) {
        return DESedeUtil.encrypt(key);
    }
    /**
     * DESede解密
     * @param ciphertext 密文
     * @param key 密钥
     * @param offset 偏移量
     * @return 解密结果
     */
    @GetMapping("/DESede/decode")
    public Object encryptionDESedeDecode(String key,String ciphertext,String offset) {
        if (StringUtils.isEmpty(offset)) {
            return DESedeUtil.decrypt(ciphertext,key);
        }
        return DESedeUtil.decrypt(ciphertext,key,offset);
    }

    /**
     * AES加密
     * @param key 明文
     * @return 加密结果
     */
    @GetMapping("/AES")
    public Object encryptionAES(String key) {
        return AESUtil.encrypt(key);
    }
    /**
     * AES解密
     * @param key 密钥
     * @param ciphertext 密文
     * @return 解密结果
     */
    @GetMapping("/AES/decode")
    public Object encryptionAESDecode(String ciphertext,String key,String offset) {
        if (!StringUtils.isEmpty(offset)) {
            return AESUtil.decrypt(ciphertext,key,offset);
        }
        return AESUtil.decrypt(ciphertext,key);
    }
    /**
     * 获取RSA密钥
     * @param level 密钥安全级别
     * @return 解密结果
     */
    @PostMapping("/RSA")
    public Object encryptionRSA(@RequestBody RSAKeyLevel level) {
        if (!Objects.isNull(level)) {
            return RSAUtil.genKeyPair(level);
        }
        return RSAUtil.genKeyPair();
    }
    /**
     * RSA加密
     * @param ciphertext 密文
     * @param publicKey 接收方公钥
     * @param privateKey 发送方私钥
     * @return 加密结果
     */
    @GetMapping("/RSA/encrypt")
    public Object encryptionRSAEncrypt(String ciphertext,String publicKey,String privateKey) {
        return RSAUtil.encrypt(ciphertext,publicKey,privateKey);
    }
    /**
     * RSA解密
     * @param ciphertext 密文
     * @param publicKey 接收方公钥
     * @param SignData 密文签名
     * @param privateKey 发送方私钥
     * @return 解密结果
     */
    @GetMapping("/RSA/decode")
    public Object encryptionRSADecode(String ciphertext,String publicKey,String SignData,String privateKey) {
        return RSAUtil.decrypt(ciphertext, privateKey, SignData, publicKey);
    }

}
