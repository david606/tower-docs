package com.chinatower.component.email.controller;

import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

@Slf4j
@RestController
@RequestMapping("/email")
public class EmailController {


    // idc 环境下的邮件接口
    private final String sendEmailUrl = "http://10.180.22.53:8765/email/sendMail";

    /**
     * @param reToEmail  收件人邮箱
     * @param reCcEmail  抄送人邮箱
     * @param reBccEmail 密送人邮箱
     * @param subject    主题
     * @param text       邮件内容
     * @param content    邮件内容
     * @param isSSL      是否加密
     * @param isUrgent   是否紧急
     * @param files      附件
     * @return
     */
    @PostMapping("/sendEmail")
    public String sendEmail(@RequestParam(value = "reToEmail", required = true) String reToEmail,
                            @RequestParam(value = "reCcEmail", required = false) String reCcEmail,
                            @RequestParam(value = "reBccEmail", required = false) String reBccEmail,
                            @RequestParam(value = "subject", required = true) String subject,
                            @RequestParam(value = "text", required = false) String text,
                            @RequestParam(value = "content", required = false) String content,
                            @RequestParam(value = "isSSL", required = false, defaultValue = "1") Integer isSSL,
                            @RequestParam(value = "isUrgent", required = false, defaultValue = "false") Boolean isUrgent,
                            @RequestParam(value = "files", required = false) MultipartFile[] files) {
        String rtn = "邮件发送失败";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        MultiValueMap<String, Object> params = new LinkedMultiValueMap<>();
        params.add("reToEmail", reToEmail);
        params.add("reCcEmail", reCcEmail);
        params.add("reBccEmail", reBccEmail);
        params.add("subject", subject);
        params.add("text", text);
        params.add("content", content);
        params.add("isSSL", isSSL);
        params.add("isUrgent", isUrgent);
        try {
            if (files != null) {
                for (MultipartFile file : files) {
                    String originalFilename = file.getOriginalFilename();
                    log.info(originalFilename);
                    ByteArrayResource byteArrayResource = new ByteArrayResource(file.getBytes()) {
                        @Override
                        public long contentLength() {
                            return file.getSize();
                        }

                        @Override
                        public String getFilename() {
                            return file.getOriginalFilename();
                        }
                    };
                    params.add("file", byteArrayResource);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        org.springframework.http.HttpEntity<MultiValueMap<String, Object>> entity = new org.springframework.http.HttpEntity<>(params, headers);
        log.info("调用邮件组件 http请求入参 sendEmailUrl:{}, entity:{}", sendEmailUrl, entity);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> responseEntity = restTemplate.postForEntity(sendEmailUrl, entity, String.class);
        log.info("调用邮件组件 http请求响应 responseEntity:{}", responseEntity);
        if (responseEntity.getStatusCodeValue() == 200) {
            String code = JSON.parseObject(responseEntity.getBody()).getString("code");
            String msg = JSON.parseObject(responseEntity.getBody()).getString("msg");
            rtn = msg;
        }
        return rtn;

    }
}
