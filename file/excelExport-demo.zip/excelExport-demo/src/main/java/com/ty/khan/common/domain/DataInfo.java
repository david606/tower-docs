package com.ty.khan.common.domain;

import lombok.Data;

@Data
public class DataInfo {
	private long id;
	private String name;
	private String phone;
}
