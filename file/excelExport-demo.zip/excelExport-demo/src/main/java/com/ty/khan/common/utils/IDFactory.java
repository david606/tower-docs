package com.ty.khan.common.utils;

import java.util.UUID;

/**
 * @ClassName IDFactory
 * @Description: TODO
 * @Author yangbin
 * @Date 2020/4/10
 * @Version V1.0
 **/
public class IDFactory {

    private final static String  lowercase = "abcdefghijklmnopqrstuvwxyz";

    /**
     * 返回32位不重复码
     * @return
     */
    public  static String getIDStr() {
        UUID uuid = UUID.randomUUID();
        String id = uuid.toString().replace("-", "");
        return id;
    }

    /**
     * 截取uuid前八位和后八位
     * @return
     */
    public static String getUUID(){
        UUID uuid = UUID.randomUUID();
        String random = uuid.toString().replace("-","");
        random = random.substring(8, random.length()-8);
        return random;
    }

    /**
     * 生成一个纯小写字母的随机字符串
     * @param num  生成的字符串长度
     * @return
     */
    public static String getRandomLetter(int num){
        StringBuilder random = new StringBuilder();
        for (int i = 0; i < num; i++) {
            random.append(lowercase.charAt((int)(Math.random() * 26)));
        }
        return random.toString();
    }
}
