package com.ty.khan.common.service.impl;

import com.alibaba.fastjson.JSONArray;
import com.chinatower.export.ExportDataRegister;
import com.chinatower.export.ExportManager;
import com.chinatower.export.info.PageInfo;
import com.chinatower.export.info.ParamInfo;
import com.ty.khan.common.domain.DataInfo;
import com.ty.khan.common.service.ExportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

@Service
public class ExportServiceImpl implements ExportService {
    @Autowired
    private HttpServletRequest req;

    @Autowired
    private HttpServletResponse res;

    @Override
    public PageInfo<DataInfo> getData(ParamInfo<?> paramInfo) throws Exception {
        String json = readFileByLines("/dataList.json");
        //转换成集合中的数据
        List<DataInfo> list = JSONArray.parseArray(json,DataInfo.class);
        PageInfo<DataInfo> info = new PageInfo<>();
        info.setList(list);
        //todo 这里必须要设置
        info.setPageSize(200);
        info.setTotal(100);
        return info;
    }

    @Override
    public void setFilePath(String s, String s1, String s2, String s3) throws Exception {

    }

    @Override
    public void exportTest() {
        ExportManager export = new ExportManager("singleHeaderTest");
        export.writeData("exportServiceImpl", null, null);
        export.exportExcel(res, req);
    }


    private String readFileByLines(String filePath) throws Exception {
        StringBuffer str = new StringBuffer();
        BufferedReader reader = null;
        try {
            //reader = new BufferedReader(new InputStreamReader(findClassLoader().getResourceAsStream(filePath), "UTF-8"));
            reader = new BufferedReader(new InputStreamReader(ExportServiceImpl.class.getResourceAsStream(filePath), "UTF-8"));
            String tempString = null;
            // 一次读入一行，直到读入null为文件结束
            while ((tempString = reader.readLine()) != null) {
                str = str.append(" " + tempString);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e1) {
                }
            }
        }
        return str.toString();
    }
}
