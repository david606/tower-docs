package com.ty.khan.common.domain;

/**
 * 枚举常量类
 * wangwei 2019-10-09
 */

public enum ResponseEnum {
    SUCCESS(200, "操作成功"),
    FAILED(400, "操作失败");
    private int code;
    private String desc;

    ResponseEnum(int code, String desc) {
        this.code = code;
        this.desc = desc;

    }

    public static ResponseEnum get(int respCode) {
        ResponseEnum[] elements = ResponseEnum.values();
        int length = elements.length;
        for (int i = 0; i < length; i++) {
            if (elements[i].getCode() == respCode) return elements[i];
        }
        return null;
    }

    public int getCode() {
        return code;
    }



    public String getDesc() {
        return desc;
    }



}
