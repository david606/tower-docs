package com.ty.khan.common.domain;

import java.util.Date;

public class Need {
    private Integer wid;
    private String  title;
    private Integer projectId;
    private Integer projectWorkitemId;
    private Integer keyTaskId;
    private Integer keyTaskNumber;

    //里程碑数据
    private Integer mid;
    private String mileTitle;
    private String mileTarget;
    private String mileOverTime;
    private String mileWeight;
    private String mileProgress;

    //任务书数据
    private Integer tid;
    private String bookTitle;
    private String bookTarget;
    private String finshTime;
    private String bookDept;
    private String bookPerson;
    private String bookWeight;
    private String bookProgress;
    private Integer keyBookId;
    private String bookDeliverable;

    //绩效表数据
    private Integer pid;
    private String performanceTitle;
    private String performanceTarget;
    private String evaluationTime;
    private String performanceDefinition;
    private String performanceAttr;
    private String performanceWeight;
    private String dataSource;
    private String evaluatedSubject;
    private String evaluationSubject;
    private String evaluationResult;

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public Integer getProjectWorkitemId() {
        return projectWorkitemId;
    }

    public void setProjectWorkitemId(Integer projectWorkitemId) {
        this.projectWorkitemId = projectWorkitemId;
    }

    public Integer getMid() {
        return mid;
    }

    public void setMid(Integer mid) {
        this.mid = mid;
    }

    public String getMileTitle() {
        return mileTitle;
    }

    public void setMileTitle(String mileTitle) {
        this.mileTitle = mileTitle;
    }

    public String getMileTarget() {
        return mileTarget;
    }

    public void setMileTarget(String mileTarget) {
        this.mileTarget = mileTarget;
    }

    public String getMileWeight() {
        return mileWeight;
    }

    public void setMileWeight(String mileWeight) {
        this.mileWeight = mileWeight;
    }

    public String getMileProgress() {
        return mileProgress;
    }

    public void setMileProgress(String mileProgress) {
        this.mileProgress = mileProgress;
    }

    public Integer getKeyTaskId() {
        return keyTaskId;
    }

    public void setKeyTaskId(Integer keyTaskId) {
        this.keyTaskId = keyTaskId;
    }

    public Integer getKeyTaskNumber() {
        return keyTaskNumber;
    }

    public void setKeyTaskNumber(Integer keyTaskNumber) {
        this.keyTaskNumber = keyTaskNumber;
    }

    public Integer getTid() {
        return tid;
    }

    public void setTid(Integer tid) {
        this.tid = tid;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public String getBookTarget() {
        return bookTarget;
    }

    public void setBookTarget(String bookTarget) {
        this.bookTarget = bookTarget;
    }

    public String getBookDept() {
        return bookDept;
    }

    public void setBookDept(String bookDept) {
        this.bookDept = bookDept;
    }

    public String getBookPerson() {
        return bookPerson;
    }

    public void setBookPerson(String bookPerson) {
        this.bookPerson = bookPerson;
    }

    public String getBookWeight() {
        return bookWeight;
    }

    public void setBookWeight(String bookWeight) {
        this.bookWeight = bookWeight;
    }

    public String getBookProgress() {
        return bookProgress;
    }

    public void setBookProgress(String bookProgress) {
        this.bookProgress = bookProgress;
    }

    public Integer getKeyBookId() {
        return keyBookId;
    }

    public void setKeyBookId(Integer keyBookId) {
        this.keyBookId = keyBookId;
    }

    public String getBookDeliverable() {
        return bookDeliverable;
    }

    public void setBookDeliverable(String bookDeliverable) {
        this.bookDeliverable = bookDeliverable;
    }

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public String getPerformanceTitle() {
        return performanceTitle;
    }

    public void setPerformanceTitle(String performanceTitle) {
        this.performanceTitle = performanceTitle;
    }

    public String getPerformanceTarget() {
        return performanceTarget;
    }

    public void setPerformanceTarget(String performanceTarget) {
        this.performanceTarget = performanceTarget;
    }

    public String getPerformanceDefinition() {
        return performanceDefinition;
    }

    public void setPerformanceDefinition(String performanceDefinition) {
        this.performanceDefinition = performanceDefinition;
    }

    public String getPerformanceAttr() {
        return performanceAttr;
    }

    public void setPerformanceAttr(String performanceAttr) {
        this.performanceAttr = performanceAttr;
    }

    public String getPerformanceWeight() {
        return performanceWeight;
    }

    public void setPerformanceWeight(String performanceWeight) {
        this.performanceWeight = performanceWeight;
    }

    public String getDataSource() {
        return dataSource;
    }

    public void setDataSource(String dataSource) {
        this.dataSource = dataSource;
    }

    public String getEvaluatedSubject() {
        return evaluatedSubject;
    }

    public void setEvaluatedSubject(String evaluatedSubject) {
        this.evaluatedSubject = evaluatedSubject;
    }

    public String getEvaluationSubject() {
        return evaluationSubject;
    }

    public void setEvaluationSubject(String evaluationSubject) {
        this.evaluationSubject = evaluationSubject;
    }

    public String getEvaluationResult() {
        return evaluationResult;
    }

    public void setEvaluationResult(String evaluationResult) {
        this.evaluationResult = evaluationResult;
    }

    public Integer getWid() {
        return wid;
    }

    public void setWid(Integer wid) {
        this.wid = wid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMileOverTime() {
        return mileOverTime;
    }

    public void setMileOverTime(String mileOverTime) {
        this.mileOverTime = mileOverTime;
    }

    public String getFinshTime() {
        return finshTime;
    }

    public void setFinshTime(String finshTime) {
        this.finshTime = finshTime;
    }

    public String getEvaluationTime() {
        return evaluationTime;
    }

    public void setEvaluationTime(String evaluationTime) {
        this.evaluationTime = evaluationTime;
    }
}
