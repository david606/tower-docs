package com.ty.khan.common.utils;

import org.springframework.core.io.ClassPathResource;
import org.springframework.util.ResourceUtils;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class TimeUtil {
    public static void main(String[] args) throws IOException, ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        //ClassPathResource resource = new ClassPathResource("excel/timeConvert.txt");
        File file = new File("src/main/resources/timeConvert.txt");
        //File file = resource.getFile();
        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
        String timeStr;
        while ((timeStr = br.readLine()) != null){
            System.out.println(sdf.parse(timeStr).getTime());

        }
    }
}
