package com.ty.khan.common.service;

import com.chinatower.export.ExportDataRegister;

public interface ExportService extends ExportDataRegister {
    void exportTest();
}