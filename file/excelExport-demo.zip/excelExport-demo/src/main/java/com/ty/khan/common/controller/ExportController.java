package com.ty.khan.common.controller;

import com.chinatower.export.AsynchronousExportManager;
import com.chinatower.export.ExportManager;
import com.chinatower.export.WriteDataInfo;
import com.chinatower.export.info.ParamInfo;
import com.ty.khan.common.domain.ResponseEnum;
import com.ty.khan.common.domain.Result;
import com.ty.khan.common.service.ExportService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/v1/export")
@Slf4j
public class ExportController {

    @Autowired
    private ExportService exportService;

    @RequestMapping(value = "/khan/template", method = RequestMethod.GET)
    public Result exportTest() {
        try {
            exportService.exportTest();
            return new Result(ResponseEnum.SUCCESS.getCode(), ResponseEnum.SUCCESS.getDesc(), null);
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(ResponseEnum.FAILED.getCode(), ResponseEnum.FAILED.getDesc(), e.getMessage());
        }
    }

    @RequestMapping("excel")
    public String excel() {
        AsynchronousExportManager instance = AsynchronousExportManager.getInstance();
        ExportManager exportManager = new ExportManager("singleHeaderTest");
        List<WriteDataInfo> list = new ArrayList<>();
        list.add(new WriteDataInfo("sheet1Data", "ckl sheet", new ParamInfo<>(), null, "singleHeaderTest"));
        list.add(new WriteDataInfo("sheet1Data", "ckl2 sheet2", new ParamInfo<>(), null, "singleHeaderTest"));
//        exportManager.writeDatas(list);
//        exportManager.writeData("sheet1Data", new ParamInfo<>(), null);
        instance.exportDatas("ckl test", "singleHeaderTest", "sheet1Data", list, false, "task1");
//        exportManager.exportExcel("./");

        return "success";
    }
}
