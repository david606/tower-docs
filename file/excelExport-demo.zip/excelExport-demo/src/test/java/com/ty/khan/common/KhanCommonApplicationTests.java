package com.ty.khan.common;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KhanCommonApplicationTests {

    @Test
    void contextLoads() {
    }

}
