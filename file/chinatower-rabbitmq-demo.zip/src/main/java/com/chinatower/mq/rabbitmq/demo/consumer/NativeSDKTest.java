package com.chinatower.mq.rabbitmq.demo.consumer;
import com.chinatower.mq.rabbitmq.client.consumer.ConsumerMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * 配置文件中配置的bean名称要和@Component注入的名称一致
 * #队列和消费类的绑定关系
 *         queueconsumers:
 *           #其中的test_direct为队列名称  nativeSDKTest和nativeSDKTest2为消费类,Spring容器中的bean名称
 *           maps: {'test_direct':['nativeSDKTest','nativeSDKTest2']}
 *
 */
@Component("nativeSDKTest")
@Slf4j
public class NativeSDKTest implements ConsumerMessage {
    @Override
    public <T> T ack(String consumerRecord) {
        log.info("接收到消息:{}",consumerRecord);
        return null;
    }
}
