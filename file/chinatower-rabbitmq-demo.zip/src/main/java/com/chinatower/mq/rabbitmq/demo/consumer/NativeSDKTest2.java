package com.chinatower.mq.rabbitmq.demo.consumer;

import com.chinatower.mq.rabbitmq.client.consumer.ConsumerMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component("nativeSDKTest2")
@Slf4j
public class NativeSDKTest2 implements ConsumerMessage {

    @Override
    public <T> T ack(String consumerRecord) {
        log.info("接收到消息nativeSDKTest2:{}" , consumerRecord);
        return null;
    }
}
