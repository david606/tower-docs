package com.chinatower.mq.rabbitmq.demo.producer;
import com.chinatower.mq.rabbitmq.client.util.MqProducerUtils;
import com.chinatower.mq.rabbitmq.entity.SendMessageParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Maxs.Marcel
 * @since 2021/5/6
 */
@RestController
@RequestMapping("/test")
public class TestProducer {
    @Autowired
    private MqProducerUtils mqProducerUtils;

    @RequestMapping("sendMessage")
    public boolean sendMessage(@RequestBody SendMessageParam param){
        return mqProducerUtils.sendMsgNative(param);
    }

}
