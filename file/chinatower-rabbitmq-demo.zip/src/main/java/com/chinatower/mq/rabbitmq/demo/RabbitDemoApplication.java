package com.chinatower.mq.rabbitmq.demo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class RabbitDemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(RabbitDemoApplication.class,args);
    }
}
