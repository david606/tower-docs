package com.chinatower.product.examples.bpm.camunda.engine.listeners;

import com.chinatower.product.bpm.modules.engine.events.TaskFinishEvent;
import com.chinatower.product.bpm.modules.engine.events.TaskFinishEvent.TaskFinishPayload;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

@Component
public class TaskFinishEventListener implements ApplicationListener<TaskFinishEvent> {
    private static Logger log = LoggerFactory.getLogger(TaskFinishEventListener.class);

    /**
     * 任务完成通知回调
     *
     * @param event the event to respond to
     */
    @Override
    public void onApplicationEvent(TaskFinishEvent event) {
        TaskFinishPayload payload = event.getPayloadObj();
        log.info("TaskFinishEventListener payload: {}", payload);
    }
}
