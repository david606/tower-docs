package com.chinatower.product.examples.bpm.camunda.engine.foura.config;

import com.chinatower.cloud.starter.foura.FourAParamsProvider;
import com.chinatower.cloud.starter.foura.utils.ThreeDESUtil;
import com.chinatower.cloud.starter.gateway.mapper.FourASecretMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class MyFourAParamsProviderImpl implements FourAParamsProvider {
    private static final Logger log = LoggerFactory.getLogger(MyFourAParamsProviderImpl.class);
    @Autowired
    private FourASecretMapper fourASecretMapper;
    @Value("${spring.application.syscode}")
    private String sysCode;

    /**
     * 获取4A同步最新密钥
     *
     * @return 密钥
     */
    @Override
    public String getSecretKey() {
        return ThreeDESUtil.decode(fourASecretMapper.selectSecretKey());
    }

    /**
     * 获取登录名
     *
     * @return 登录名
     */
    @Override
    public String getLoginAcct() {
        return "zb-tongls";
    }

    /**
     * 获取系统编码
     *
     * @return 系统编码
     */
    @Override
    public String getSysCode() {
        return sysCode;
    }
}
