package com.chinatower.product.examples.bpm.camunda.engine;

import com.chinatower.cloud.starter.foura.entity.query4A.user.PageUserRsp;
import com.chinatower.cloud.starter.foura.entity.query4A.user.User;
import com.chinatower.cloud.starter.foura.service.FourAQuery4AService;
import com.chinatower.cloud.starter.gateway.utils.ThreeDESUtil;
import com.chinatower.framework.common_service.response.Page;
import com.chinatower.framework.common_service.response.PageRespResult;
import com.chinatower.product.bpm.modules.engine.assignee.V1Beta1AssigneeQueryApi;
import com.chinatower.product.bpm.modules.engine.api.*;
import com.chinatower.product.bpm.modules.engine.entity.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.seata.spring.annotation.GlobalTransactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.*;

@RestController
@RequestMapping("/test")
public class TestController {

    @Autowired
    private V1Beta1DeploymentApi deploymentControllerApiClient;

    @Autowired
    private V1Beta1ProcessDefinitionApi processDefinitionApiClient;

    @Autowired
    private V1Beta1HistoricTaskInstanceApiClient v1Beta1HistoricTaskInstanceApiClient;

    @Autowired
    private V1Beta1ProcessInstanceApi processInstanceApiClient;

    @Autowired
    private V1Beta1TaskApi taskApiClient;
    @Autowired
    private V1Beta1FilterApi filterApi;
    @Autowired
    private V1Beta1HistoricActivityInstanceApi api;

    @Autowired
    private V1Beta1AssigneeQueryApi assigneeQueryApi;

    @Autowired
    private V1Beta1TaskVariableApi taskVariableApi;

    @Autowired
    private V1Beta1TaskLocalVariableApi taskLocalVariableApi;
    /**
     * 部署
     */
    @PostMapping("/create")
    public DeploymentDto create(@RequestBody V1Beta1DeployDto dto) {
        return deploymentControllerApiClient.createWithNameAndContent(dto);
    }

    /**
     * 创建默认模板
     */
    @PostMapping("/createDeployByTemplate")
    @GlobalTransactional
    public ProcessDefinitionDto createDeployByTemplate(@RequestBody V1Beta1TemplateDeployDto v1Beta1TemplateDeployDto) {
        ProcessDefinitionDto deployByTemplate = deploymentControllerApiClient.createDeployByTemplate(v1Beta1TemplateDeployDto);
        if(true){
            throw new RuntimeException("ex");
        }
        return deployByTemplate;
    }

    /**
     * 通过ID查询部署
     */
    @GetMapping("/getDeployment")
    public DeploymentDto getDeployment() {
        String s = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><bpmn:definitions xmlns:bpmn=\"http://www.omg.org/spec/BPMN/20100524/MODEL\" xmlns:bpmndi=\"http://www.omg.org/spec/BPMN/20100524/DI\" xmlns:dc=\"http://www.omg.org/spec/DD/20100524/DC\" xmlns:camunda=\"http://camunda.org/schema/1.0/bpmn\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:di=\"http://www.omg.org/spec/DD/20100524/DI\" xmlns:modeler=\"http://camunda.org/schema/modeler/1.0\" id=\"Definitions_0oi2o9f\" targetNamespace=\"http://bpmn.io/schema/bpmn\" exporter=\"Camunda Modeler\" exporterVersion=\"5.16.0\" modeler:executionPlatform=\"Camunda Platform\" modeler:executionPlatformVersion=\"7.20.0\">  <bpmn:process id=\"Process_1j7ljyd\" isExecutable=\"true\" camunda:historyTimeToLive=\"180\">    <bpmn:extensionElements />    <bpmn:startEvent id=\"StartEvent_1\">      <bpmn:extensionElements>        <camunda:properties>          <camunda:property />        </camunda:properties>      </bpmn:extensionElements>      <bpmn:outgoing>Flow_0hr1dtw</bpmn:outgoing>    </bpmn:startEvent>    <bpmn:sequenceFlow id=\"Flow_0hr1dtw\" sourceRef=\"StartEvent_1\" targetRef=\"Activity_0v5i2l8\" />    <bpmn:exclusiveGateway id=\"Gateway_0ykox7g\" default=\"Flow_1rhpx4z\">      <bpmn:incoming>Flow_1gpg1jm</bpmn:incoming>      <bpmn:outgoing>Flow_1rhpx4z</bpmn:outgoing>      <bpmn:outgoing>Flow_1r2jnl5</bpmn:outgoing>      <bpmn:outgoing>Flow_1dv0xc1</bpmn:outgoing>      <bpmn:outgoing>Flow_1gdqsta</bpmn:outgoing>      <bpmn:outgoing>Flow_0hea1ns</bpmn:outgoing>    </bpmn:exclusiveGateway>    <bpmn:sequenceFlow id=\"Flow_1gpg1jm\" sourceRef=\"Activity_0v5i2l8\" targetRef=\"Gateway_0ykox7g\" />    <bpmn:userTask id=\"Activity_0v5i2l8\" camunda:assignee=\"${assignee}\">      <bpmn:extensionElements>        <camunda:properties>          <camunda:property name=\"act_start\" value=\"true\" />        </camunda:properties>      </bpmn:extensionElements>      <bpmn:incoming>Flow_0hr1dtw</bpmn:incoming>      <bpmn:outgoing>Flow_1gpg1jm</bpmn:outgoing>      <bpmn:outgoing>Flow_0yvyj0j</bpmn:outgoing>      <bpmn:multiInstanceLoopCharacteristics camunda:collection=\"assigneeList1\" camunda:elementVariable=\"assignee\" />    </bpmn:userTask>    <bpmn:sequenceFlow id=\"Flow_1rhpx4z\" sourceRef=\"Gateway_0ykox7g\" targetRef=\"Activity_12u6cvl\" />    <bpmn:sequenceFlow id=\"Flow_1r2jnl5\" sourceRef=\"Gateway_0ykox7g\" targetRef=\"Activity_02bzvto\">      <bpmn:conditionExpression xsi:type=\"bpmn:tFormalExpression\">${money==1}</bpmn:conditionExpression>    </bpmn:sequenceFlow>    <bpmn:sequenceFlow id=\"Flow_1dv0xc1\" sourceRef=\"Gateway_0ykox7g\" targetRef=\"Activity_1s2wt8v\">      <bpmn:conditionExpression xsi:type=\"bpmn:tFormalExpression\">${money==2}</bpmn:conditionExpression>    </bpmn:sequenceFlow>    <bpmn:userTask id=\"Activity_12u6cvl\" name=\"guan\" camunda:assignee=\"guanqp\">      <bpmn:incoming>Flow_1rhpx4z</bpmn:incoming>      <bpmn:outgoing>Flow_1kynsyc</bpmn:outgoing>    </bpmn:userTask>    <bpmn:userTask id=\"Activity_02bzvto\" name=\"zhuang\" camunda:assignee=\"zhuangzy\">      <bpmn:incoming>Flow_1r2jnl5</bpmn:incoming>      <bpmn:outgoing>Flow_010vz43</bpmn:outgoing>    </bpmn:userTask>    <bpmn:userTask id=\"Activity_1s2wt8v\" name=\"tongls\" camunda:assignee=\"tongls\">      <bpmn:incoming>Flow_1dv0xc1</bpmn:incoming>      <bpmn:outgoing>Flow_1l6gagq</bpmn:outgoing>    </bpmn:userTask>    <bpmn:sequenceFlow id=\"Flow_1kynsyc\" sourceRef=\"Activity_12u6cvl\" targetRef=\"Gateway_1l8ystw\">      <bpmn:conditionExpression xsi:type=\"bpmn:tFormalExpression\">${money==-1}</bpmn:conditionExpression>    </bpmn:sequenceFlow>    <bpmn:sequenceFlow id=\"Flow_010vz43\" sourceRef=\"Activity_02bzvto\" targetRef=\"Gateway_1l8ystw\" />    <bpmn:sequenceFlow id=\"Flow_1l6gagq\" sourceRef=\"Activity_1s2wt8v\" targetRef=\"Gateway_1l8ystw\" />    <bpmn:inclusiveGateway id=\"Gateway_1l8ystw\" default=\"Flow_18f7zk7\">      <bpmn:incoming>Flow_1kynsyc</bpmn:incoming>      <bpmn:incoming>Flow_010vz43</bpmn:incoming>      <bpmn:incoming>Flow_1l6gagq</bpmn:incoming>      <bpmn:incoming>Flow_1gdqsta</bpmn:incoming>      <bpmn:incoming>Flow_19louwt</bpmn:incoming>      <bpmn:outgoing>Flow_18f7zk7</bpmn:outgoing>      <bpmn:outgoing>Flow_0y96xy0</bpmn:outgoing>      <bpmn:outgoing>Flow_1ptet9o</bpmn:outgoing>      <bpmn:outgoing>Flow_0iakd9x</bpmn:outgoing>    </bpmn:inclusiveGateway>    <bpmn:sequenceFlow id=\"Flow_18f7zk7\" sourceRef=\"Gateway_1l8ystw\" targetRef=\"Activity_0und6aj\" />    <bpmn:sequenceFlow id=\"Flow_0y96xy0\" sourceRef=\"Gateway_1l8ystw\" targetRef=\"Activity_087c0r5\">      <bpmn:conditionExpression xsi:type=\"bpmn:tFormalExpression\">${money==3}</bpmn:conditionExpression>    </bpmn:sequenceFlow>    <bpmn:sequenceFlow id=\"Flow_1ptet9o\" sourceRef=\"Gateway_1l8ystw\" targetRef=\"Activity_0afuu56\">      <bpmn:conditionExpression xsi:type=\"bpmn:tFormalExpression\">${money&lt;3}</bpmn:conditionExpression>    </bpmn:sequenceFlow>    <bpmn:userTask id=\"Activity_041p0x9\" name=\"guan\" camunda:assignee=\"${assignee}\">      <bpmn:extensionElements>        <camunda:properties>          <camunda:property name=\"act_role_var1\" value=\"roleName\" />          <camunda:property name=\"act_account_var\" value=\"CTxxx1\" />          <camunda:property name=\"act_org_\" value=\"chnt001\" />        </camunda:properties>      </bpmn:extensionElements>      <bpmn:incoming>Flow_0iakd9x</bpmn:incoming>      <bpmn:outgoing>Flow_1inv4nj</bpmn:outgoing>      <bpmn:multiInstanceLoopCharacteristics camunda:collection=\"assigneeList\" camunda:elementVariable=\"assignee\" />    </bpmn:userTask>    <bpmn:userTask id=\"Activity_0und6aj\" name=\"liu\" camunda:assignee=\"liull\">      <bpmn:incoming>Flow_18f7zk7</bpmn:incoming>      <bpmn:outgoing>Flow_0e861fm</bpmn:outgoing>    </bpmn:userTask>    <bpmn:userTask id=\"Activity_087c0r5\" name=\"zhuang\" camunda:assignee=\"zhuangzy\">      <bpmn:incoming>Flow_0y96xy0</bpmn:incoming>      <bpmn:outgoing>Flow_1qn1szo</bpmn:outgoing>    </bpmn:userTask>    <bpmn:userTask id=\"Activity_0afuu56\" name=\"qiao\" camunda:assignee=\"qiaowh\">      <bpmn:incoming>Flow_1ptet9o</bpmn:incoming>      <bpmn:outgoing>Flow_0lfmxv0</bpmn:outgoing>    </bpmn:userTask>    <bpmn:endEvent id=\"Event_0a5125q\">      <bpmn:incoming>Flow_1inv4nj</bpmn:incoming>      <bpmn:incoming>Flow_0e861fm</bpmn:incoming>      <bpmn:incoming>Flow_1qn1szo</bpmn:incoming>      <bpmn:incoming>Flow_0lfmxv0</bpmn:incoming>      <bpmn:incoming>Flow_1blsomd</bpmn:incoming>      <bpmn:incoming>Flow_11kxjc8</bpmn:incoming>      <bpmn:incoming>Flow_0uz2fl9</bpmn:incoming>    </bpmn:endEvent>    <bpmn:sequenceFlow id=\"Flow_1inv4nj\" sourceRef=\"Activity_041p0x9\" targetRef=\"Event_0a5125q\" />    <bpmn:sequenceFlow id=\"Flow_0e861fm\" sourceRef=\"Activity_0und6aj\" targetRef=\"Event_0a5125q\" />    <bpmn:sequenceFlow id=\"Flow_1qn1szo\" sourceRef=\"Activity_087c0r5\" targetRef=\"Event_0a5125q\" />    <bpmn:sequenceFlow id=\"Flow_0lfmxv0\" sourceRef=\"Activity_0afuu56\" targetRef=\"Event_0a5125q\" />    <bpmn:sequenceFlow id=\"Flow_1gdqsta\" sourceRef=\"Gateway_0ykox7g\" targetRef=\"Gateway_1l8ystw\">      <bpmn:conditionExpression xsi:type=\"bpmn:tFormalExpression\">${money==4}</bpmn:conditionExpression>    </bpmn:sequenceFlow>    <bpmn:sequenceFlow id=\"Flow_0hea1ns\" sourceRef=\"Gateway_0ykox7g\" targetRef=\"Activity_0cpajaf\">      <bpmn:conditionExpression xsi:type=\"bpmn:tFormalExpression\">${money==3}</bpmn:conditionExpression>    </bpmn:sequenceFlow>    <bpmn:sequenceFlow id=\"Flow_19louwt\" sourceRef=\"Activity_0cpajaf\" targetRef=\"Gateway_1l8ystw\" />    <bpmn:userTask id=\"Activity_0cpajaf\" name=\"root\" camunda:assignee=\"root\">      <bpmn:incoming>Flow_0hea1ns</bpmn:incoming>      <bpmn:outgoing>Flow_19louwt</bpmn:outgoing>    </bpmn:userTask>    <bpmn:sequenceFlow id=\"Flow_0iakd9x\" sourceRef=\"Gateway_1l8ystw\" targetRef=\"Activity_041p0x9\">      <bpmn:conditionExpression xsi:type=\"bpmn:tFormalExpression\">${money==4}</bpmn:conditionExpression>    </bpmn:sequenceFlow>    <bpmn:parallelGateway id=\"Gateway_135tefg\">      <bpmn:incoming>Flow_0yvyj0j</bpmn:incoming>      <bpmn:outgoing>Flow_0vrvyzg</bpmn:outgoing>      <bpmn:outgoing>Flow_0phgt99</bpmn:outgoing>      <bpmn:outgoing>Flow_1uo5zmk</bpmn:outgoing>    </bpmn:parallelGateway>    <bpmn:sequenceFlow id=\"Flow_0vrvyzg\" sourceRef=\"Gateway_135tefg\" targetRef=\"Activity_1f354lr\" />    <bpmn:sequenceFlow id=\"Flow_0phgt99\" sourceRef=\"Gateway_135tefg\" targetRef=\"Activity_0pwm7lo\" />    <bpmn:sequenceFlow id=\"Flow_1uo5zmk\" sourceRef=\"Gateway_135tefg\" targetRef=\"Activity_0islbz5\" />    <bpmn:sequenceFlow id=\"Flow_0yvyj0j\" sourceRef=\"Activity_0v5i2l8\" targetRef=\"Gateway_135tefg\">      <bpmn:conditionExpression xsi:type=\"bpmn:tFormalExpression\">${money&gt;100}</bpmn:conditionExpression>    </bpmn:sequenceFlow>    <bpmn:sequenceFlow id=\"Flow_1blsomd\" sourceRef=\"Activity_1f354lr\" targetRef=\"Event_0a5125q\" />    <bpmn:sequenceFlow id=\"Flow_11kxjc8\" sourceRef=\"Activity_0pwm7lo\" targetRef=\"Event_0a5125q\" />    <bpmn:sequenceFlow id=\"Flow_0uz2fl9\" sourceRef=\"Activity_0islbz5\" targetRef=\"Event_0a5125q\" />    <bpmn:userTask id=\"Activity_1f354lr\" name=\"guan\" camunda:assignee=\"guanqp\">      <bpmn:incoming>Flow_0vrvyzg</bpmn:incoming>      <bpmn:outgoing>Flow_1blsomd</bpmn:outgoing>    </bpmn:userTask>    <bpmn:userTask id=\"Activity_0pwm7lo\" name=\"zhuangzy\" camunda:assignee=\"zhuangzy\">      <bpmn:incoming>Flow_0phgt99</bpmn:incoming>      <bpmn:outgoing>Flow_11kxjc8</bpmn:outgoing>    </bpmn:userTask>    <bpmn:userTask id=\"Activity_0islbz5\" name=\"tongls\" camunda:assignee=\"tongls\">      <bpmn:incoming>Flow_1uo5zmk</bpmn:incoming>      <bpmn:outgoing>Flow_0uz2fl9</bpmn:outgoing>    </bpmn:userTask>  </bpmn:process>  <bpmndi:BPMNDiagram id=\"BPMNDiagram_1\">    <bpmndi:BPMNPlane id=\"BPMNPlane_1\" bpmnElement=\"Process_1j7ljyd\">      <bpmndi:BPMNShape id=\"_BPMNShape_StartEvent_2\" bpmnElement=\"StartEvent_1\">        <dc:Bounds x=\"179\" y=\"82\" width=\"36\" height=\"36\" />      </bpmndi:BPMNShape>      <bpmndi:BPMNShape id=\"Gateway_0ykox7g_di\" bpmnElement=\"Gateway_0ykox7g\" isMarkerVisible=\"true\">        <dc:Bounds x=\"355\" y=\"325\" width=\"50\" height=\"50\" />      </bpmndi:BPMNShape>      <bpmndi:BPMNShape id=\"Activity_1n1u4y1_di\" bpmnElement=\"Activity_0v5i2l8\">        <dc:Bounds x=\"147\" y=\"310\" width=\"100\" height=\"80\" />      </bpmndi:BPMNShape>      <bpmndi:BPMNShape id=\"Activity_15ynh8c_di\" bpmnElement=\"Activity_12u6cvl\">        <dc:Bounds x=\"530\" y=\"310\" width=\"100\" height=\"80\" />        <bpmndi:BPMNLabel />      </bpmndi:BPMNShape>      <bpmndi:BPMNShape id=\"Activity_03dppkg_di\" bpmnElement=\"Activity_02bzvto\">        <dc:Bounds x=\"530\" y=\"420\" width=\"100\" height=\"80\" />        <bpmndi:BPMNLabel />      </bpmndi:BPMNShape>      <bpmndi:BPMNShape id=\"Activity_105wpkc_di\" bpmnElement=\"Activity_1s2wt8v\">        <dc:Bounds x=\"530\" y=\"530\" width=\"100\" height=\"80\" />        <bpmndi:BPMNLabel />      </bpmndi:BPMNShape>      <bpmndi:BPMNShape id=\"Gateway_0oeb9oh_di\" bpmnElement=\"Gateway_1l8ystw\">        <dc:Bounds x=\"755\" y=\"325\" width=\"50\" height=\"50\" />      </bpmndi:BPMNShape>      <bpmndi:BPMNShape id=\"Activity_0e0kd5l_di\" bpmnElement=\"Activity_041p0x9\">        <dc:Bounds x=\"930\" y=\"87\" width=\"100\" height=\"80\" />        <bpmndi:BPMNLabel />      </bpmndi:BPMNShape>      <bpmndi:BPMNShape id=\"Activity_1os86q3_di\" bpmnElement=\"Activity_0und6aj\">        <dc:Bounds x=\"930\" y=\"190\" width=\"100\" height=\"80\" />        <bpmndi:BPMNLabel />      </bpmndi:BPMNShape>      <bpmndi:BPMNShape id=\"Activity_18a8zne_di\" bpmnElement=\"Activity_087c0r5\">        <dc:Bounds x=\"930\" y=\"420\" width=\"100\" height=\"80\" />        <bpmndi:BPMNLabel />      </bpmndi:BPMNShape>      <bpmndi:BPMNShape id=\"Activity_0riecbv_di\" bpmnElement=\"Activity_0afuu56\">        <dc:Bounds x=\"930\" y=\"530\" width=\"100\" height=\"80\" />        <bpmndi:BPMNLabel />      </bpmndi:BPMNShape>      <bpmndi:BPMNShape id=\"Event_0a5125q_di\" bpmnElement=\"Event_0a5125q\">        <dc:Bounds x=\"1152\" y=\"332\" width=\"36\" height=\"36\" />      </bpmndi:BPMNShape>      <bpmndi:BPMNShape id=\"Activity_1vwjhk1_di\" bpmnElement=\"Activity_0cpajaf\">        <dc:Bounds x=\"530\" y=\"640\" width=\"100\" height=\"80\" />        <bpmndi:BPMNLabel />      </bpmndi:BPMNShape>      <bpmndi:BPMNShape id=\"Gateway_172bzov_di\" bpmnElement=\"Gateway_135tefg\">        <dc:Bounds x=\"535\" y=\"765\" width=\"50\" height=\"50\" />      </bpmndi:BPMNShape>      <bpmndi:BPMNShape id=\"Activity_0o6d7j3_di\" bpmnElement=\"Activity_1f354lr\">        <dc:Bounds x=\"720\" y=\"750\" width=\"100\" height=\"80\" />        <bpmndi:BPMNLabel />      </bpmndi:BPMNShape>      <bpmndi:BPMNShape id=\"Activity_1ldk9ek_di\" bpmnElement=\"Activity_0pwm7lo\">        <dc:Bounds x=\"720\" y=\"860\" width=\"100\" height=\"80\" />        <bpmndi:BPMNLabel />      </bpmndi:BPMNShape>      <bpmndi:BPMNShape id=\"Activity_0j1le2w_di\" bpmnElement=\"Activity_0islbz5\">        <dc:Bounds x=\"720\" y=\"970\" width=\"100\" height=\"80\" />        <bpmndi:BPMNLabel />      </bpmndi:BPMNShape>      <bpmndi:BPMNEdge id=\"Flow_0hr1dtw_di\" bpmnElement=\"Flow_0hr1dtw\">        <di:waypoint x=\"197\" y=\"118\" />        <di:waypoint x=\"197\" y=\"310\" />      </bpmndi:BPMNEdge>      <bpmndi:BPMNEdge id=\"Flow_1gpg1jm_di\" bpmnElement=\"Flow_1gpg1jm\">        <di:waypoint x=\"247\" y=\"350\" />        <di:waypoint x=\"355\" y=\"350\" />      </bpmndi:BPMNEdge>      <bpmndi:BPMNEdge id=\"Flow_1rhpx4z_di\" bpmnElement=\"Flow_1rhpx4z\">        <di:waypoint x=\"405\" y=\"350\" />        <di:waypoint x=\"530\" y=\"350\" />      </bpmndi:BPMNEdge>      <bpmndi:BPMNEdge id=\"Flow_1r2jnl5_di\" bpmnElement=\"Flow_1r2jnl5\">        <di:waypoint x=\"380\" y=\"375\" />        <di:waypoint x=\"380\" y=\"460\" />        <di:waypoint x=\"530\" y=\"460\" />      </bpmndi:BPMNEdge>      <bpmndi:BPMNEdge id=\"Flow_1dv0xc1_di\" bpmnElement=\"Flow_1dv0xc1\">        <di:waypoint x=\"380\" y=\"375\" />        <di:waypoint x=\"380\" y=\"570\" />        <di:waypoint x=\"530\" y=\"570\" />      </bpmndi:BPMNEdge>      <bpmndi:BPMNEdge id=\"Flow_1kynsyc_di\" bpmnElement=\"Flow_1kynsyc\">        <di:waypoint x=\"630\" y=\"350\" />        <di:waypoint x=\"755\" y=\"350\" />      </bpmndi:BPMNEdge>      <bpmndi:BPMNEdge id=\"Flow_010vz43_di\" bpmnElement=\"Flow_010vz43\">        <di:waypoint x=\"630\" y=\"460\" />        <di:waypoint x=\"780\" y=\"460\" />        <di:waypoint x=\"780\" y=\"375\" />      </bpmndi:BPMNEdge>      <bpmndi:BPMNEdge id=\"Flow_1l6gagq_di\" bpmnElement=\"Flow_1l6gagq\">        <di:waypoint x=\"630\" y=\"570\" />        <di:waypoint x=\"780\" y=\"570\" />        <di:waypoint x=\"780\" y=\"375\" />      </bpmndi:BPMNEdge>      <bpmndi:BPMNEdge id=\"Flow_18f7zk7_di\" bpmnElement=\"Flow_18f7zk7\">        <di:waypoint x=\"780\" y=\"325\" />        <di:waypoint x=\"780\" y=\"230\" />        <di:waypoint x=\"930\" y=\"230\" />      </bpmndi:BPMNEdge>      <bpmndi:BPMNEdge id=\"Flow_0y96xy0_di\" bpmnElement=\"Flow_0y96xy0\">        <di:waypoint x=\"780\" y=\"375\" />        <di:waypoint x=\"780\" y=\"460\" />        <di:waypoint x=\"930\" y=\"460\" />      </bpmndi:BPMNEdge>      <bpmndi:BPMNEdge id=\"Flow_1ptet9o_di\" bpmnElement=\"Flow_1ptet9o\">        <di:waypoint x=\"780\" y=\"375\" />        <di:waypoint x=\"780\" y=\"570\" />        <di:waypoint x=\"930\" y=\"570\" />      </bpmndi:BPMNEdge>      <bpmndi:BPMNEdge id=\"Flow_1inv4nj_di\" bpmnElement=\"Flow_1inv4nj\">        <di:waypoint x=\"1030\" y=\"127\" />        <di:waypoint x=\"1091\" y=\"127\" />        <di:waypoint x=\"1091\" y=\"350\" />        <di:waypoint x=\"1152\" y=\"350\" />      </bpmndi:BPMNEdge>      <bpmndi:BPMNEdge id=\"Flow_0e861fm_di\" bpmnElement=\"Flow_0e861fm\">        <di:waypoint x=\"1030\" y=\"230\" />        <di:waypoint x=\"1091\" y=\"230\" />        <di:waypoint x=\"1091\" y=\"350\" />        <di:waypoint x=\"1152\" y=\"350\" />      </bpmndi:BPMNEdge>      <bpmndi:BPMNEdge id=\"Flow_1qn1szo_di\" bpmnElement=\"Flow_1qn1szo\">        <di:waypoint x=\"1030\" y=\"460\" />        <di:waypoint x=\"1091\" y=\"460\" />        <di:waypoint x=\"1091\" y=\"350\" />        <di:waypoint x=\"1152\" y=\"350\" />      </bpmndi:BPMNEdge>      <bpmndi:BPMNEdge id=\"Flow_0lfmxv0_di\" bpmnElement=\"Flow_0lfmxv0\">        <di:waypoint x=\"1030\" y=\"570\" />        <di:waypoint x=\"1091\" y=\"570\" />        <di:waypoint x=\"1091\" y=\"350\" />        <di:waypoint x=\"1152\" y=\"350\" />      </bpmndi:BPMNEdge>      <bpmndi:BPMNEdge id=\"Flow_1gdqsta_di\" bpmnElement=\"Flow_1gdqsta\">        <di:waypoint x=\"380\" y=\"325\" />        <di:waypoint x=\"380\" y=\"190\" />        <di:waypoint x=\"780\" y=\"190\" />        <di:waypoint x=\"780\" y=\"325\" />      </bpmndi:BPMNEdge>      <bpmndi:BPMNEdge id=\"Flow_0hea1ns_di\" bpmnElement=\"Flow_0hea1ns\">        <di:waypoint x=\"380\" y=\"375\" />        <di:waypoint x=\"380\" y=\"680\" />        <di:waypoint x=\"530\" y=\"680\" />      </bpmndi:BPMNEdge>      <bpmndi:BPMNEdge id=\"Flow_19louwt_di\" bpmnElement=\"Flow_19louwt\">        <di:waypoint x=\"630\" y=\"680\" />        <di:waypoint x=\"780\" y=\"680\" />        <di:waypoint x=\"780\" y=\"375\" />      </bpmndi:BPMNEdge>      <bpmndi:BPMNEdge id=\"Flow_0iakd9x_di\" bpmnElement=\"Flow_0iakd9x\">        <di:waypoint x=\"780\" y=\"325\" />        <di:waypoint x=\"780\" y=\"127\" />        <di:waypoint x=\"930\" y=\"127\" />      </bpmndi:BPMNEdge>      <bpmndi:BPMNEdge id=\"Flow_0vrvyzg_di\" bpmnElement=\"Flow_0vrvyzg\">        <di:waypoint x=\"585\" y=\"790\" />        <di:waypoint x=\"720\" y=\"790\" />      </bpmndi:BPMNEdge>      <bpmndi:BPMNEdge id=\"Flow_0phgt99_di\" bpmnElement=\"Flow_0phgt99\">        <di:waypoint x=\"560\" y=\"815\" />        <di:waypoint x=\"560\" y=\"900\" />        <di:waypoint x=\"720\" y=\"900\" />      </bpmndi:BPMNEdge>      <bpmndi:BPMNEdge id=\"Flow_1uo5zmk_di\" bpmnElement=\"Flow_1uo5zmk\">        <di:waypoint x=\"560\" y=\"815\" />        <di:waypoint x=\"560\" y=\"1010\" />        <di:waypoint x=\"720\" y=\"1010\" />      </bpmndi:BPMNEdge>      <bpmndi:BPMNEdge id=\"Flow_0yvyj0j_di\" bpmnElement=\"Flow_0yvyj0j\">        <di:waypoint x=\"197\" y=\"390\" />        <di:waypoint x=\"197\" y=\"790\" />        <di:waypoint x=\"535\" y=\"790\" />      </bpmndi:BPMNEdge>      <bpmndi:BPMNEdge id=\"Flow_1blsomd_di\" bpmnElement=\"Flow_1blsomd\">        <di:waypoint x=\"820\" y=\"790\" />        <di:waypoint x=\"1170\" y=\"790\" />        <di:waypoint x=\"1170\" y=\"368\" />      </bpmndi:BPMNEdge>      <bpmndi:BPMNEdge id=\"Flow_11kxjc8_di\" bpmnElement=\"Flow_11kxjc8\">        <di:waypoint x=\"820\" y=\"900\" />        <di:waypoint x=\"1170\" y=\"900\" />        <di:waypoint x=\"1170\" y=\"368\" />      </bpmndi:BPMNEdge>      <bpmndi:BPMNEdge id=\"Flow_0uz2fl9_di\" bpmnElement=\"Flow_0uz2fl9\">        <di:waypoint x=\"820\" y=\"1010\" />        <di:waypoint x=\"1170\" y=\"1010\" />        <di:waypoint x=\"1170\" y=\"368\" />      </bpmndi:BPMNEdge>    </bpmndi:BPMNPlane>  </bpmndi:BPMNDiagram></bpmn:definitions>";
        return deploymentControllerApiClient.getDeployment("0219f4a2-89e7-11ee-ada3-60a5e2499e59");
    }

    /**
     * 复制流程定义
     */
    @PostMapping("/copyProcessDefinition")
    public DeploymentDto copyProcessDefinition() {
        String processDefinitionId = "Process_0cytjzq1108:1:a023bd71-8390-11ee-9525-60a5e2499e59";

        V1Beta1DeployDto dto = new V1Beta1DeployDto();
        dto.setDeploymentName("请假流程111");
        dto.setTenantId("ABC");
        dto.setDeployChangedOnly(false);
        dto.setEnableDuplicateFiltering(false);

        return processDefinitionApiClient.copyProcessDefinition(processDefinitionId, dto);
    }

    @PostMapping("/startProcessInstanceById")
    public ProcessInstanceDto startProcessInstanceById(@RequestBody V1Beta1StartProcessInstanceDto startProcessInstanceDto) {

        ProcessInstanceDto processInstanceDto = processDefinitionApiClient.startProcessInstanceById(startProcessInstanceDto);

        if(true){
            throw new RuntimeException("ex");
        }

        return processInstanceDto;
    }

    /**
     * 条件查询流程定义
     */
    @GetMapping("/getProcessDefinitions")
    public PageRespResult<List<ProcessDefinitionDto>> getProcessDefinitions(@RequestParam String id) {
        ProcessDefinitionQueryDto queryDto = new ProcessDefinitionQueryDto();
        queryDto.setProcessDefinitionId(id);

//        queryDto.setDeploymentId("ae9101c5-8de5-11ee-b8a2-7277255490d9");

//        ArrayList<String> tenantIds = new ArrayList<>();
//        tenantIds.add("ABC");
//        queryDto.setTenantIdIn(tenantIds);

        return processDefinitionApiClient.getProcessDefinitions(queryDto, 1, 10);

    }

    /**
     * 查看流程定义详情
     */
    @GetMapping("/xml")
    public ProcessDefinitionDiagramDto getProcessDefinitionBpmn20Xml() {
        String processDefinitionId = "Process_00blxf2:1:aea462b7-8de5-11ee-b8a2-7277255490d9";

        return processDefinitionApiClient.getProcessDefinitionBpmn20Xml(processDefinitionId);
    }

    /**
     * 版本列表查看
     */
    @GetMapping("/getAllVersion")
    public PageRespResult<List<ProcessDefinitionDto>> getAllVersion() {
        ProcessDefinitionQueryDto queryDto = new ProcessDefinitionQueryDto();
        // 流程定义实体中的key
        queryDto.setKey("Process_00blxf2");
        ArrayList<String> tenantId = new ArrayList<>();
        queryDto.setTenantIdIn(tenantId);

        return processDefinitionApiClient.getProcessDefinitions(queryDto, 1, 10);
    }

    /**
     * 审批通过
     */
    @PostMapping("/complete")
    public Map<String, VariableValueDto> complete() {
        String taskId = "815d8975-d47f-11ee-b1b2-8a66fe1c1e03";

        CompleteTaskDto dto = new CompleteTaskDto();

        return taskApiClient.complete(taskId, dto);
    }

    /**
     * 审批驳回
     */
    @PostMapping("/reject")
    public void reject() {
        V1Beta1TaskRejectDto dto = new V1Beta1TaskRejectDto();

        dto.setTaskId("eedea6bc-8cf1-11ee-b081-4abd9dced3f5");
        dto.setType("last");
        dto.setRejectComment("驳回说明");
        dto.rejectToTaskDefKey("Activity_0iyyd28");

        taskApiClient.reject(dto);
    }

    /**
     * 废除流程
     */
    @DeleteMapping("/businessDelete")
    public void businessDelete(@RequestParam("id") String id) { // id必填
        String deleteReason = "发起人废除"; // 废除原因（选填）

        processInstanceApiClient.businessDelete(id, deleteReason, false, false, false, false);
    }

    /**
     * 查询待办
     */
    @GetMapping("/getTasks")
    public PageRespResult<List<TaskDto>> getTasks() {
        TaskQueryDto queryDto = new TaskQueryDto();
        ArrayList<String> tenantId = new ArrayList<>();
        queryDto.setTenantIdIn(tenantId);
        PageRespResult<List<TaskDto>> tasks = taskApiClient.getTasks(queryDto, 1, 10);
        return tasks;
    }


    /**
     * 普通减签
     */
    @PostMapping("/reduceSign")
    public void reduceSign() {

        TaskDto taskDto = new TaskDto();
        taskDto.setTaskDefinitionKey("Activity_1awpjnq");
        taskDto.processDefinitionId("Process_1120_3:1:36afcd3e-876d-11ee-8294-60a5e2499e59");
        taskDto.processInstanceId("8aafb53f-876d-11ee-8294-60a5e2499e59");
        taskDto.setAssignee("qiaowh");

        taskApiClient.reduceSign(taskDto);
    }

    /**
     * 撤回
     */
    @PostMapping("/retract")
    public void retract(String taskId) {
        try {
            taskApiClient.retract(taskId);
        }catch (Exception e){
            System.out.println(e);
        }

    }


    @Autowired
    private FourAQuery4AService fourAQuery4AService;

    /**
     * 查询4A用户
     *
     * @param userName    用户名
     * @param userCode    用户编码
     * @param mobile      手机号
     * @param email       邮箱
     * @param status      状态
     * @param roleCode    角色编码
     * @param orgCode     组织编码
     * @param currentPage 当前页
     * @param pageSize    每页长度
     * @return 用户分页信息
     * @throws JsonProcessingException json序列化异常
     */
    @GetMapping("/query/4a/users")
    public PageUserRsp users(@RequestParam(required = false, defaultValue = "") String userName,
                             @RequestParam(required = false, defaultValue = "") String userCode,
                             @RequestParam(required = false, defaultValue = "") String mobile,
                             @RequestParam(required = false, defaultValue = "") String email,
                             @RequestParam(required = false, defaultValue = "0") Integer status,
                             @RequestParam(required = false, defaultValue = "") String roleCode,
                             @RequestParam(required = false, defaultValue = "") String orgCode,
                             @RequestParam(required = false, defaultValue = "1") Integer currentPage,
                             @RequestParam(required = false, defaultValue = "10") Integer pageSize) throws JsonProcessingException {
        PageUserRsp pageUser4ARspResult = fourAQuery4AService.queryUsers(userName, userCode, mobile, email, status, roleCode, orgCode, currentPage, pageSize);
        return pageUser4ARspResult;
    }

    /**
     * 查询历史活动实例
     *
     * @param queryDto 查询参数
     * @return 历史活动实例分页
     */
    @PostMapping("/queryHistoricActivityInstances")
    public PageRespResult<List<HistoricActivityInstanceDto>> queryHistoricActivityInstances(@RequestBody HistoricActivityInstanceQueryDto queryDto) {
        /**
         * queryDto负责对活动实例进行检索，条件选填
         * {
         *     "processInstanceId": "d9474254-b5c3-11ee-8cfd-2e8cdbbc4142"
         *     // "startedAfter": "2023/12/28 14:11:45"
         * }
         */
//        queryDto.setStartedBefore(new V1Beta1BpmDateTime(new Date()));
//        queryDto.setStartedBefore(new V1Beta1BpmDateTime());
        PageRespResult<List<HistoricActivityInstanceDto>> listPageRespResult = api.queryHistoricActivityInstances(queryDto, 1, 10);

        return listPageRespResult;
    }

    @Autowired
    private V1Beta1AssigneeQueryApi v1Beta1AssigneeQueryApi;

    /**
     * 查询办理人
     *
     * @param taskId 任务ID
     * @return 办理人
     * @throws JsonProcessingException json序列化异常
     */
    @GetMapping("/queryAssignee")
    public List<User> queryAssignee(@RequestParam String taskId) throws JsonProcessingException {
        return v1Beta1AssigneeQueryApi.queryNextActivityAssignees(taskId);
    }

    /**
     * 创建过滤器
     *
     * @param filterDto 过滤器实体
     * @return 过滤器信息
     */
    @PostMapping("/createFilter")
    public FilterDto createFilter(@RequestBody FilterDto filterDto) {
        FilterDto filter = filterApi.createFilter(filterDto);
        return filter;
    }

    /**
     * 通过ID查询过滤器
     *
     * @param id 过滤器ID
     * @return 过滤器信息
     */
    @GetMapping("/getFilter")
    public FilterDto getFilter(@RequestParam("id") String id) {
        FilterDto filter = filterApi.getFilter(id, true);
        return filter;
    }

    /**
     * 条件查询过滤器
     *
     * @param queryDto 查询参数
     * @return 过滤器集
     */
    @GetMapping("/getFilters")
    public PageRespResult<List<FilterDto>> getFilters(FilterQueryDto queryDto) {
        PageRespResult<List<FilterDto>> filters = filterApi.getFilters(queryDto, true, 1, 10);
        return filters;
    }

    /**
     * 查询待办
     *
     * @param id 过滤器ID
     * @return 待办信息
     */
    @GetMapping("/queryListWithProcessInfo")
    public PageRespResult<List<V1Beta1HalTaskDto>> queryListWithProcessInfo(@RequestParam("id") String id) { // 过滤器ID（必填）

        /**
         * queryDto负责对结果集进行二次过滤，选填
         * {
         * 	//"taskId": "109fe38d-bdb8-11ee-9cbd-f60dcb23bf0b"
         * 	//"processInstanceId": "828fe1c5-be81-11ee-bb12-00163e010e70",
         * 	"processVariables": [
         *                {
         * 			"operator": "eq",
         * 			"value": 1,
         * 			"name": "objectType"
         *        }
         * 	],
         * 	"createdBefore": "2023/02/23 14:55:00"
         * }
         */


        // 结果集过滤参数
        TaskQueryDto taskQueryDto = new TaskQueryDto();
        taskQueryDto.setAssignee("madl5");
        ArrayList<VariableQueryParameterDto> arrayList = new ArrayList<>();
        VariableQueryParameterDto parameterDto = new VariableQueryParameterDto();
        parameterDto.setName("objectType");
        parameterDto.setValue(1);
        parameterDto.setOperator("eq");
        arrayList.add(parameterDto);
        taskQueryDto.setProcessVariables(arrayList);
        taskQueryDto.setCreatedBefore(new Date("2024/01/06 00:00:00"));
        taskQueryDto.setCreatedAfter(new Date("2024/02/07 23:59:59"));
//        taskQueryDto.taskId("xxxxxxxxxxxxxxxx");
//        taskQueryDto.setCreated(new V1Beta1BpmDateTime());
//         taskQueryDto.setCreated(new V1Beta1BpmDateTime(new Date()));
//         taskQueryDto.setCreated(new V1Beta1BpmDateTime("时间str"));

        // 查询结果
        PageRespResult<List<V1Beta1HalTaskDto>> result = filterApi.queryListWithProcessInfo(id, taskQueryDto, 1, 10);
        // 结果集
        List<V1Beta1HalTaskDto> data = result.getData();
        // 分页信息
        Page page = result.getPage();
        return result;
    }

    /**
     * 流程发起之前查询起草人节点下一个环节候选审批人
     *
     * @param id        任务ID
     * @param variables 变量
     * @return 审批人
     * @throws JsonProcessingException json序列化异常
     */
    @GetMapping("/queryPreProcessFirstAssignees")
    public PageRespResult<List<User>> queryPreProcessFirstAssignees(@RequestParam String id, @RequestBody Map<String, VariableValueDto> variables) throws JsonProcessingException {
        List<User> users = assigneeQueryApi.queryPreProcessFirstAssignees(id, variables);
        return PageRespResult.SUCCESS(users);
    }

    /**
     * 启动默认模板
     *
     * @param dto 启动流程参数
     * @return 流程实例信息
     */
    @PostMapping("/startPublicTemplate")
    public ProcessInstanceDto startPublicTemplate(@RequestBody V1Beta1StartProcessInstanceDto dto) {
        /**
         * dto示例：
         * {
         *     "processDefinitionId": "013c372b-d790-11ee-b308-0e1114855c0c",
         *     "businessKey": "test_instance_20240101",
         *     "variables": {
         *         "act_start_user": {
         *             "value": "zhangsan",
         *             "type": "String"
         *         },
         *         "abc": {
             *          "value": "[\"lisi\",\"wangwu\",\"zhaoliu\"]",
             * 			"type": "Object",
             * 			"valueInfo": {
             * 				"objectTypeName": "java.util.ArrayList",
             * 				"serializationDataFormat": "application/json"
             *          }
         *         }
         *     }
         * }
         */
        dto.setProcessDefinitionId("流程定义ID");
        dto.setBusinessKey("业务键");
        // act_start_user 含义为流程发起人，流程启动时的必传变量
        Map<String, VariableValueDto> variable = new HashMap<>();
        VariableValueDto variableValueDto = new VariableValueDto();
        variableValueDto.setType(String.class.getSimpleName());
        variableValueDto.setValue("zhangsan");
        variable.put("act_start_user", variableValueDto);
        dto.setVariables(variable);

        ProcessInstanceDto processInstanceDto = processDefinitionApiClient.startPublicTemplate(dto);
        return processInstanceDto;
    }

    /**
     * 获取任务列表
     *
     * @param id 流程实例ID
     * @return 任务列表
     */
    @GetMapping("/tasksList")
    public Object tasksList(String id) {
        QueryUserOperationLogParam dto = new QueryUserOperationLogParam();
        dto.setProcessInstanceId(id);
        PageRespResult<List<V1Beta1UserOperationLogDto>> page = v1Beta1HistoricTaskInstanceApiClient.getHistoricTaskList(dto, 1, 10);
        return page;
    }

    @GetMapping("/queryHistoricPageWithProcessInfo")
    public String queryHistoricPageWithProcessInfo(){
        HistoricTaskInstanceQueryDto historicTaskInstanceQueryDto=new HistoricTaskInstanceQueryDto();
        historicTaskInstanceQueryDto.taskAssignee("liull");
        historicTaskInstanceQueryDto.startedBefore(new Date());
        /*List<VariableQueryParameterDto> processVariables=new ArrayList<>();
        VariableQueryParameterDto variableQueryParameterDto=new VariableQueryParameterDto();
        variableQueryParameterDto.name("act_start_time");
        variableQueryParameterDto.operator("gt");
        variableQueryParameterDto.value(1706693805925L);
        processVariables.add(variableQueryParameterDto);
        historicTaskInstanceQueryDto.processVariables(processVariables);*/
        PageRespResult<List<V1Beta1HalTaskDto>> listPageRespResult = filterApi.queryHistoricPageWithProcessInfo("b6b5872d-aba4-11ee-9caa-5ebb2a55671x", historicTaskInstanceQueryDto, 1, 10);
        System.out.println(listPageRespResult);
        return "ok";

    }


    @PutMapping("/putVariable")
    @GlobalTransactional
    public String putVariable(String taskId,String variableName){
        VariableValueDto variableValueDto=new VariableValueDto();
        variableValueDto.setValue("asd");
        variableValueDto.setType(String.class.getSimpleName());
        taskVariableApi.putVariable(taskId,variableName,variableValueDto);
        return "ok";
    }


    @DeleteMapping("/deleteVariable")
    @GlobalTransactional
    public String deleteVariable(String taskId,String variableName){
        taskVariableApi.deleteVariable(taskId,variableName);
        if(true){
            throw new RuntimeException("ex");
        }
        return "oK";
    }

    @PostMapping("/modifyVariables")
    @GlobalTransactional
    public String modifyVariables(String taskId, @RequestBody PatchVariablesDto patch){
        taskVariableApi.modifyVariables(taskId,patch);
        if(true){
            throw new RuntimeException("ex");
        }
        return "ok";
    }

    @PutMapping("/putLocalVariable")
    @GlobalTransactional
    public String putLocalVariable(String taskId,String variableName){
        VariableValueDto variableValueDto=new VariableValueDto();
        variableValueDto.setValue("asd");
        variableValueDto.setType(String.class.getSimpleName());
        taskLocalVariableApi.putVariable1(taskId,variableName,variableValueDto);
        return "ok";
    }


    @DeleteMapping("/deleteLocalVariable")
    @GlobalTransactional
    public String deleteLocalVariable(String taskId,String variableName){
        taskLocalVariableApi.deleteVariable1(taskId,variableName);
        if(true){
            throw new RuntimeException("ex");
        }
        return "oK";
    }

    @PostMapping("/modifyLocalVariables")
    @GlobalTransactional
    public String modifyLocalVariables(String taskId, @RequestBody PatchVariablesDto patch){
        taskLocalVariableApi.modifyVariables1(taskId,patch);
        if(true){
            throw new RuntimeException("ex");
        }
        return "ok";
    }

    @PostMapping("/completeTask")
    public String completeTask(String taskId){
        CompleteTaskDto completeTaskDto=new CompleteTaskDto();
        completeTaskDto.setWithVariablesInReturn(false);
        taskApiClient.complete(taskId,completeTaskDto);
        return "ok";
    }

    @PostMapping("/addSign")
    @GlobalTransactional
    public String addSign(@RequestBody TaskDto taskDto){
        taskApiClient.addSign(taskDto);
        if(true){
            throw new RuntimeException("ex");
        }
        return "ok";
    }


    @PostMapping("/completeAndComment")
    public Map<String, VariableValueDto> completeAndComment(@RequestBody V1Beta1CompleteTaskDto dto) {
        // taskId 必填
        String id = "20cd4d1f-d51c-11ee-b597-a6395509a224";
        /**
         * "completeDesc": "审批意见", // 审批意见（选填）
         * "variables": { // 冗余参数（选填）
         * 		"managers": {
         * 			"value": "zhangsan",
         * 			"type": "String"
         * 		},
         * 	    "name": {
         *          "value": "[\"lisi\",\"wangwu\",\"zhaoliu\"]",
         *          "type": "Object",
         *          "valueInfo": {
         *              "objectTypeName": "java.util.ArrayList",
         *              "serializationDataFormat": "application/json"
         *          }
         *      }
         * 	}
         */
        Map<String, VariableValueDto> stringVariableValueDtoMap = taskApiClient.completeAndComment(id, dto);
        return stringVariableValueDtoMap;
    }

    @PostMapping("/createWithNameAndContent")
    @GlobalTransactional
    public DeploymentDto createWithNameAndContent(@RequestBody V1Beta1DeployDto dto) {
        DeploymentDto deploymentDto = deploymentControllerApiClient.createWithNameAndContent(dto);
//        if (!ObjectUtils.isEmpty(deploymentDto)) {
//            throw new RuntimeException("sss");
//        }
        return deploymentDto;
    }

    /**
     * 完成任务并添加评论，并支持设置下一环节办理人
     *
     * @param taskId 任务ID
     * @param dto    审批意见、冗余参数、下一环节审批人
     */
    @PostMapping("/completeWithCommentAndChangeNextActivityAssignee")
    public Map<String, VariableValueDto> completeWithCommentAndChangeNextActivityAssignee(@RequestParam("taskId") String taskId, @RequestBody V1Beta1CompleteTaskDto dto) {
        /**
         * {
         * 	"variables": {
         * 		"managers": {
         * 			"value": "起草人审批完成",
         * 			"type": "String",
         * 			"valueInfo": {
         * 				"objectTypeName": "java.lang.String",
         * 				"serializationDataFormat": "application/json"
         *          }
         *        }
         *    },
         * 	"assignees": [
         * 		"lidan6",
         * 		"madl5"
         * 	]
         * }
         */
        Map<String, VariableValueDto> stringVariableValueDtoMap = taskApiClient.completeWithCommentAndChangeNextActivityAssignee(taskId, dto);
        return stringVariableValueDtoMap;
    }


    public static void main(String[] args) {
        // 日志中的applyUuidCrpt
        String s = "150EADB4C56465A51C030D74644F4A60BDE15CE96EBB02D12EAD22D1AFC72D3086937A993B88113E";
        // 日志中的uuid
        String appuuid = "9b3887f6-0c8a-422a-b7a7-13083959b3ea";
        System.out.println("日志中的: " + s);



        // 数据库密钥
        String keyEn = "2EDEB93294047399"; // 新密钥
//        String keyEn = "99BF2FBDED07FC0C"; // 旧密钥
        String decode = ThreeDESUtil.decode(keyEn);
        String applyUuidCrpt = ThreeDESUtil.encode(appuuid, "@*1Qtz3Y");
        System.out.println("新生成的: " + applyUuidCrpt);
    }


}
