package com.chinatower.product.examples.bpm.camunda.engine.gateway;

import com.chinatower.cloud.starter.gateway.utils.ThreeDESUtil;
import feign.RequestInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.UUID;

/**
 * @Author: liull
 * @Date: 2024/3/20 16:46
 */
@Configuration
public class GatewayConfig {

    @Bean("apiGatewayRequestInterceptor")
    public RequestInterceptor requestInterceptor() {
        return requestTemplate -> {
            String key = "E^#e*w$5";
            String appUuid = UUID.randomUUID().toString();
            String applyUuidCrpt = ThreeDESUtil.encode(appUuid, key);
            requestTemplate.header("APPID", "CHNTXXXX");
            requestTemplate.header("APPUUID", appUuid);
            requestTemplate.header("APPUUIDCRPT", applyUuidCrpt);
            requestTemplate.header("ACCESSIPADDR", "127.0.0.1");
        };
    }
}
