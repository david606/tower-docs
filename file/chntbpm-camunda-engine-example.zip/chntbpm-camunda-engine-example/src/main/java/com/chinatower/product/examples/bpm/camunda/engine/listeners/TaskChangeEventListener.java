package com.chinatower.product.examples.bpm.camunda.engine.listeners;

import com.chinatower.product.bpm.modules.engine.events.TaskChangeEvent;
import com.chinatower.product.bpm.modules.engine.events.TaskChangeEvent.TaskChangePayload;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

@Component
public class TaskChangeEventListener implements ApplicationListener<TaskChangeEvent> {
    private static Logger log = LoggerFactory.getLogger(TaskChangeEventListener.class);

    /**
     * 任务修改通知回调
     *
     * @param event the event to respond to
     */
    @Override
    public void onApplicationEvent(TaskChangeEvent event) {
        TaskChangePayload payload = event.getPayloadObj();
        log.info("TaskChangeEventListener payload: {}", payload);
    }
}
