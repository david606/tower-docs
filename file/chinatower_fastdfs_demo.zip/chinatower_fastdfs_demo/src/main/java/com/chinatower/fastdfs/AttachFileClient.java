package com.chinatower.fastdfs;


import feign.Response;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

/**
 *
 * @description 上传、下载附件管理
 */
@FeignClient(url = "${system.custom.attachFileClientUrl}",name = "AttachFileClient")
public interface AttachFileClient {


    /**
     * 获取签名
     *
     * @param timestamp  时间戳
     * @param nonce      随机数
     * @param sysCode    系统编码
     * @return
     */
    @PostMapping(value = "/ChinatowerFileService/getSignature", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String, Object> getSignature(@RequestHeader("timestamp") String timestamp,
                                          @RequestHeader("nonce") String nonce,
                                          @RequestHeader("sysCode") String sysCode);
    /**
     * 文件上传
     *
     * @param signature  签名
     * @param timestamp  时间戳
     * @param nonce      随机数
     * @param sysCode    系统编码
     * @param visibilityLevel   文件可见性级别
     * @param file       文件流
     * @param userId     用户
     * @return
     */
    @PostMapping(value = "/ChinatowerFileService/uploadFile", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String, Object> uploadFile(@RequestHeader("signature") String signature,
                                          @RequestHeader("timestamp") String timestamp,
                                          @RequestHeader("nonce") String nonce,
                                          @RequestHeader("sysCode") String sysCode,
                                          @RequestParam("visibilityLevel") String visibilityLevel,
                                          @RequestPart("file") MultipartFile file,
                                          @RequestParam("userId") String userId);


    /**
     * 文件下载
     *
     * @param signature  签名
     * @param timestamp  时间戳
     * @param nonce      随机数
     * @param sysCode    系统编码
     * @param fileId     文件序号
     * @param userId     用户
     * @return
     */
    @GetMapping(value = "/ChinatowerFileService/dowloadFile")
    public Map<String, Object> dowloadFile(@RequestHeader("signature") String signature,
                                @RequestHeader("timestamp") String timestamp,
                                @RequestHeader("nonce") String nonce,
                                @RequestHeader("sysCode") String sysCode,
                                @RequestParam("fileId") String fileId,
                                @RequestParam("userId") String userId);


    /**
     * 文件删除
     *
     * @param signature  签名
     * @param timestamp  时间戳
     * @param nonce      随机数
     * @param sysCode    系统编码
     * @param fileId     文件序号
     * @param userId     用户
     * @return
     */
    @PostMapping(value = "/ChinatowerFileService/deleteFile")
    public Map<String, Object> deleteFile(@RequestHeader("signature") String signature,
                                          @RequestHeader("timestamp") String timestamp,
                                          @RequestHeader("nonce") String nonce,
                                          @RequestHeader("sysCode") String sysCode, @RequestParam("fileId") String fileId,
                                          @RequestParam("userId") String userId);


}
