package com.chinatower.fastdfs;

import com.alibaba.fastjson.JSON;
import com.chinatower.product.message.email.common.EmailConstant;
import com.chinatower.encrypt.utils.Util;
import com.chinatower.product.message.email.common.EmailResult;
import com.chinatower.product.message.email.common.EmailResultCodeEnum;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.util.Map;

/**
 * @author lkx.soul
 * @Description
 */
@Slf4j
@Configuration
public class AttachFileUtils {

    @Autowired
    AttachFileClient attachFileClient;

    @Value("${system.custom.syscode}")
    private String syscode;

    private static final String VISIBILITYLEVEL = "1001";
    private static final String USERID = "0208";
    private static final String SUCCESSCODE = "000000";
    private static final String FILE_CODE = "code";
    private static final String FILE_DATA = "data";
    private static final String FILE_MES = "mes";
    public static final String HTTP_URL = "http_url";
    public static final String FILE_ID = "file_id";


    public void uploadAttachFile(MultipartFile file) {
            String timeStamp = String.valueOf(System.currentTimeMillis());
            Map<String, Object> signatureMap = attachFileClient.getSignature(timeStamp,timeStamp,syscode);
            String signature = (String) signatureMap.get("data");
            Map<String, Object> fileResult = attachFileClient.uploadFile
                    (signature, timeStamp, timeStamp, syscode, VISIBILITYLEVEL, file, USERID);
            String code = String.valueOf(fileResult.get(FILE_CODE));
    }

    public void deleteAttachFile(String fileId) {
        String timeStamp = String.valueOf(System.currentTimeMillis());
            Map<String, Object> signatureMap = attachFileClient.getSignature(timeStamp,timeStamp,syscode);
            String signature = (String) signatureMap.get("data");
            Map<String, Object> map = attachFileClient.deleteFile(signature, timeStamp, timeStamp, syscode, fileId, USERID);
    }

    /**
     * 文件下载
     * @param fileId 文件组件返回的文件ID
     * @param rootDirect 文件路径
     */
    public Map<String, Object> downLoadAttachFile(String fileId,String rootDirect){
        String timeStamp = String.valueOf(System.currentTimeMillis());
        InputStream inputStream = null;
            Map<String, Object> signatureMap = attachFileClient.getSignature(timeStamp,timeStamp,syscode);
            String signature = (String) signatureMap.get("data");
         return attachFileClient.dowloadFile(signature, timeStamp, timeStamp, syscode, fileId, USERID);
    }
}
