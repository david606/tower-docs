package com.chinatower.cloud.examples.health.service;

public interface AccountService {

    Boolean decrease(String id, Double money) throws Exception;
    
    Boolean decrease2(String id, Double moneyTotal) throws Exception;
}
