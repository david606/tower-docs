package com.chinatower.cloud.examples.health.controller;

import com.chinatower.cloud.examples.health.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AccountController {

    @Autowired
    public AccountService accountService;

    @RequestMapping("/account/decrease")
    public String decrease(@RequestParam("id") String id, @RequestParam("money") Double money) throws Exception{
        boolean b = accountService.decrease(id, money);
        if(b) {
            return "OK";
        } else {
            return "不OK";
        }
    }
    @RequestMapping("/account/decrease2")
    public String decrease2(@RequestParam("id") String id, @RequestParam("money") Double money) throws Exception{
        boolean b = accountService.decrease2(id, money);
        if(b) {
            return "OK";
        } else {
            return "不OK";
        }
    }
}
