package com.chinatower.cloud.examples.health;

import io.seata.spring.annotation.datasource.EnableAutoDataSourceProxy;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;


@SpringBootApplication
@EnableFeignClients(basePackages = {
        "com.chinatower.cloud.examples.health",
        "com.chinatower.cloud.starter.esb"              // esb-starter需要添加feign client扫描路径
})
@EnableAutoDataSourceProxy
public class HealthEurekaExampleApplication {
    public static void main(String[] args) {
        SpringApplication.run(HealthEurekaExampleApplication.class, args);
    }
}
