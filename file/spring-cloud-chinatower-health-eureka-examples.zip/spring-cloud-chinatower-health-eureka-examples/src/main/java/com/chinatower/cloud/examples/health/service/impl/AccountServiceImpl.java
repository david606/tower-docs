package com.chinatower.cloud.examples.health.service.impl;

import com.chinatower.cloud.examples.health.dao.AccountDao;
import com.chinatower.cloud.examples.health.service.AccountService;
import io.seata.spring.annotation.GlobalLock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccountServiceImpl implements AccountService {

    private static final Logger logger = LoggerFactory.getLogger(AccountServiceImpl.class);

    @Autowired
    public AccountDao accountDao;
    
    @Override
    public Boolean decrease(String id, Double moneyTotal) throws Exception{
        logger.info("扣款");
        int count = accountDao.decreaseDemo(id, moneyTotal);
        logger.info("扣款结束, moneyTotal: " + moneyTotal + "count: " + count);
        Double money = accountDao.moneyIsEnough(id);
        if ( money < 0 ){
            throw new Exception("钱不够");
        }
        return true;
    }
    
    @Override
    @GlobalLock(lockRetryInterval = 1000)
    public Boolean decrease2(String id, Double moneyTotal) throws Exception {
        accountDao.decreaseDemo(id,moneyTotal);
        return true;
    }

}
