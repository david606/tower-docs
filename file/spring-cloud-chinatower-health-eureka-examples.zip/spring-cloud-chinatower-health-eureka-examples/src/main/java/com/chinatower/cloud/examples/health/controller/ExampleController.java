package com.chinatower.cloud.examples.health.controller;

import com.chinatower.cloud.examples.health.feign.GatewayFeignClient;
import com.chinatower.cloud.examples.health.feign.TestFeignClient;
import com.chinatower.cloud.starter.esb.EsbServiceClient;
import com.chinatower.cloud.starter.esb.InterfaceInfo;
import com.chinatower.cloud.starter.logRecord.utils.JacksonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/test")
public class ExampleController {
    private static Logger log = LoggerFactory.getLogger(ExampleController.class);
    
    @Autowired
    private TestFeignClient testFeignClient;
    
    @Autowired
    private EsbServiceClient esbServiceClient;
    
    @Autowired
    private GatewayFeignClient gatewayFeignClient;
    
    
    /**
     * 测试feign调用指标
     */
    @RequestMapping("/consumer")
    public Object consumer(){
        return testFeignClient.provider();
    }
    
    /**
     * 测试esb-starter指标
     */
    @RequestMapping("/esb")
    public Object esb() {
        String json = "{\"esbUrl\":\"http://10.180.17.6:9000/proxy\",\"isRequiredNamepace\":\"true\",\"msgId\":\"60.6002202308081745141402782\",\"paramName\":[\"info\"],\"reqMsg\":[\"[{\\\"MDMPROJECTSTATES_EXCPTIME\\\":\\\"\\\",\\\"MDMPROJECTSTATES_SUPERVISOR\\\":\\\"\\\",\\\"LASTMODIFIYTIME\\\":\\\"\\\",\\\"MDMPROJECTSTATES_DEMANDID\\\":\\\"\\\",\\\"MDMPROJECTSTATES_ROOMMCPTIME\\\":\\\"\\\",\\\"PROJECT_STATE_ID\\\":\\\"000109860000000105469028\\\",\\\"MDMPROJECTSTATES_MEMO\\\":\\\"\\\",\\\"MDMPROJECTSTATES_CODE\\\":\\\"23M01ZBZB151000005\\\",\\\"MANAGE_MODE\\\":\\\"01\\\",\\\"MDMPROJECTSTATES_TOWERCPTIME\\\":\\\"\\\",\\\"MDMPROJECTSTATES_EXIJTIME\\\":\\\"\\\",\\\"CREATOR\\\":\\\"\\\",\\\"CREATETIME\\\":\\\"\\\",\\\"EX1\\\":\\\"内部验收\\\",\\\"MDMPROJECTSTATES_ELECCPTIME\\\":\\\"\\\",\\\"MDMPROJECTSTATES_DESIGNUNIT\\\":\\\"\\\",\\\"MDMPROJECTSTATES_BUDGET\\\":\\\"\\\",\\\"MDMPROJECTSTATES_ROOMCPTIME\\\":\\\"\\\",\\\"LASTMODIFIER\\\":\\\"\\\",\\\"MDMPROJECTSTATES_EXORTIME\\\":\\\"\\\",\\\"MDMPROJECTSTATES_ACCTIFICATE\\\":\\\"\\\",\\\"PRJID\\\":30007235,\\\"MDMPROJECTSTATES_EXACCTIME\\\":\\\"\\\",\\\"MDMPROJECTSTATES_SUPERVUNIT\\\":\\\"\\\",\\\"MDMPROJECTSTATES_REALIJTIME\\\":\\\"\\\",\\\"MDMPROJECTSTATES_TIME\\\":\\\"2023-08-03 04:08:37\\\",\\\"MDMPROJECTSTATES_STATE\\\":\\\"F1\\\",\\\"FATHER_PROJECT_CODE\\\":\\\"\\\",\\\"IS_BATCH\\\":0}]\"],\"sender\":\"60.6002\",\"servCode\":\"40.4001\",\"servName\":\"PDSSProjectStatus_Budget\",\"servNamespace\":\"http://tempuri.org/\"}";
        InterfaceInfo info = JacksonUtils.fromJson(json, InterfaceInfo.class);
        String resp = esbServiceClient.invoke(info);
        return resp;
    }
    
    /**
     * 测试gateway-starter指标
     */
    @RequestMapping("/gateway")
    public Object gateway() {
        return gatewayFeignClient.provider();
    }
    
    
    /**
     * 测试日志打印指标
     */
    @RequestMapping("/log")
    public Object log(@RequestParam String level) {
        if (level == null) {
            return "success";
        }
        if ("info".equalsIgnoreCase(level)) {
            log.info("this is a info log");
        } else if("warn".equalsIgnoreCase(level)) {
            log.warn("this is a warn log");
        } else if("error".equalsIgnoreCase(level)) {
            log.error("this is a error log");
        }
        return "success";
    }
}
