package com.chinatower.cloud.examples.health.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

/**
 * @author qiaowh
 */
@FeignClient(name = "chntsentinel-test-old", fallbackFactory = TestFallbackFactory.class)
public interface TestFeignClient {
    
    @GetMapping("/provider")
    public Map<String, Object> provider();
    
    @GetMapping("/provider/randomError")
    public Map<String, Object> randomError();
    
    @GetMapping("/provider/slow")
    public Map<String, Object> slow(@RequestParam("millis") Long millis);


}
