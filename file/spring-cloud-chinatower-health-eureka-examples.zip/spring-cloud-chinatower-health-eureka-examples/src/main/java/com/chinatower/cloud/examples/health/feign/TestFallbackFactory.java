package com.chinatower.cloud.examples.health.feign;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.openfeign.FallbackFactory;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Map;

/**
 * @author wangsch
 */
@Service
public class TestFallbackFactory implements FallbackFactory<TestFeignClient> {
    private static Logger log = LoggerFactory.getLogger(TestFallbackFactory.class);
    
    @Override
    public TestFeignClient create(Throwable cause) {
        return new TestFeignClient() {
            @Override
            public Map<String, Object> provider() {
                log.info("provider fallback", cause);
                return Collections.singletonMap("fallback", true);
            }
    
            @Override
            public Map<String, Object> randomError() {
                log.info("randomError fallback", cause);
                return Collections.singletonMap("fallback", true);
            }
    
            @Override
            public Map<String, Object> slow(Long millis) {
                log.info("slow fallback", cause);
                return Collections.singletonMap("fallback", true);
            }
        };
    }
}
