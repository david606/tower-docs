package com.chinatower.cloud.examples.health.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Map;

/**
 * @author wangsch
 */
@FeignClient(value = "INNER-GATEWAY", url="10.180.22.22:8097")
public interface GatewayFeignClient {
    @GetMapping("CHNTSENTINEL-TEST-OLD/provider")
    public Map<String, Object> provider();
    
    @GetMapping("CHNTSENTINEL-TEST-OLD/provider/randomError")
    public Map<String, Object> randomError();
    
    @GetMapping("CHNTSENTINEL-TEST-OLD/provider/slow")
    public Map<String, Object> slow(Long millis);
}

