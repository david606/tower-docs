package com.chinatower.cloud.examples.health.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface AccountDao {

    @Update("UPDATE t_account set account_money = account_money - #{moneyTotal} where id = #{id}")
    int decreaseDemo(@Param("id") String id, @Param("moneyTotal") Double moneyTotal);

    @Select("SELECT  account_money FROM t_account WHERE id = #{id}")
    Double moneyIsEnough(String id);
}
