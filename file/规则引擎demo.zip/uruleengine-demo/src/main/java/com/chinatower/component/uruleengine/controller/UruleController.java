package com.chinatower.component.uruleengine.controller;

import org.springframework.http.*;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

/**
 * @author zhou
 */
@RestController
@RequestMapping("/rule")
public class UruleController {
    @Resource
    private RestTemplate restTemplate;
    @GetMapping
    public Object ruleApi() {
        HttpEntity<Map<String, Object>> requestEntity;
        HttpHeaders headers = new HttpHeaders();
        Map<String, Object> params = new HashMap<>();
        HashMap<String, String> param = new HashMap<>();
        headers.setContentType(MediaType.APPLICATION_JSON);
        params.put("projectCode", "f8bec5acd08048a5bdfd9758d04f3ac2");
        params.put("ruleCode", "test01");
        param.put("age", "20");
        params.put("params", param);
        requestEntity = new HttpEntity<>(params, headers);
        String url = "http://10.180.22.64:80/edas-rule-client/api";
        ResponseEntity<Object> response = restTemplate.postForEntity(url, requestEntity, Object.class);
        if (response.getStatusCodeValue() == HttpStatus.OK.value()) {
            Map<Object,Object> body = (Map) response.getBody();
            if (!CollectionUtils.isEmpty(body)) {
                    return body;
            }
        }
        return null;
    }
}
