package com.chinatower.autocache.demo.service;

import com.chinatower.autocache.annotation.AutoCache;
import com.chinatower.autocache.demo.entity.DemoEntity;
import org.springframework.stereotype.Service;

/**
 * @author chenkonglin
 * Description
 * CreateDate 2022-12-30 17:10
 */
@Service
public class DemoDelCacheService {
    @AutoCache(remove = true, keyGenerator = "demoKeyGenerator")
    public String demoKeyTest(DemoEntity demo) {
        return null;
    }
}
