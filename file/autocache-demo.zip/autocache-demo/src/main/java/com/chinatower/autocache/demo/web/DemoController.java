package com.chinatower.autocache.demo.web;

import com.chinatower.autocache.demo.entity.DemoEntity;
import com.chinatower.autocache.demo.service.DemoService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * @author chenkonglin
 * Description
 * CreateDate 2022-12-29 11:01
 */
@Controller
@RequestMapping("/demo")
@ResponseBody
public class DemoController {

    @Resource
    private DemoService demoService;

    @GetMapping("/stringTest")
    public String stringTest() {
        return demoService.stringTest();
    }

    @GetMapping("/booleanTest")
    public boolean booleanTest() {
        return demoService.booleanTest();
    }

    @GetMapping("/intTest")
    public int intTest() {
        return demoService.intTest();
    }

    @GetMapping("/listStringTest")
    public List<String> listStringTest() {
        return demoService.listStringTest();
    }

    @GetMapping("/listIntTest")
    public List<Integer> listIntTest() {
        return demoService.listIntTest();
    }

    @GetMapping("/demoTest")
    public DemoEntity demoTest() {
        return demoService.demoTest();
    }

    @GetMapping("/listDemoTest")
    public List<DemoEntity> listDemoTest() {
        return demoService.listDemoTest();
    }

    @GetMapping("/mapTest")
    public Map<String, Object> mapTest() {
        return demoService.mapTest();
    }

    @GetMapping("/keyTest")
    public String keyTest(@RequestParam("str") String str,@RequestParam("num") int num,
                          @RequestParam("dou") double dou,@RequestParam("boo") boolean boo) {
        return demoService.keyTest(str, num, dou, boo);
    }

    @PostMapping("/entityKeyTest")
    public String entityKeyTest(@RequestBody DemoEntity entity) {
        return demoService.entityKeyTest(entity);
    }

    @PostMapping("/demoKeyTest")
    public String demoKeyTest(@RequestBody DemoEntity entity) {
        return demoService.demoKeyTest(entity);
    }

    @GetMapping("/removeKey")
    public String removeKey() {
        return demoService.removeKey();
    }
}
