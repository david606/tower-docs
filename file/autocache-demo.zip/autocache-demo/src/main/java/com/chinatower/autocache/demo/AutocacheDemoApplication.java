package com.chinatower.autocache.demo;

import com.chinatower.autocache.annotation.EnableAutoCache;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@EnableAutoCache
@SpringBootApplication(exclude= {DataSourceAutoConfiguration.class})
@EnableTransactionManagement
public class AutocacheDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(AutocacheDemoApplication.class, args);
    }

}
