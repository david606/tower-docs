package com.chinatower.autocache.demo.service;

import com.chinatower.autocache.annotation.AutoCache;
import com.chinatower.autocache.demo.entity.DemoEntity;
import com.chinatower.autocache.operation.CacheDataOperationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;

/**
 * @author chenkonglin
 * Description
 * CreateDate 2022-12-29 11:02
 */
@Slf4j
@Service
public class DemoService {
    // 此示例，前八个方法为基础支持缓存对象，其中包括一个自定义对象 DemoEntity
    // 第九个方法为展示基本数据结构入参构造是怎么样的结果，以及展示过期时间的设置
    // 第十个方法为展示自定义对象入参的默认key生成方式生成后的key格式
    // 第十一个方法为自定义对象入参的自定义key生成方式生成后的key格式
    // 第十二个方法为展示如何移除一个需要明确更新的缓存数据.其被移除后，将在下一次被调用的时候，自动将新数据放入缓存中

    private final Random random = new Random();

    @Resource
    private DemoDelCacheService demoDelCacheService;

    @AutoCache
    public String stringTest() {
        // 使用注解缓存前后对比
        // 原有缓存使用方法
        // value = redisTemplate.opsForValue().get(key);
        // if (value == null) {
        //      value = business();
        //      redisTemplate.opsForValue().set(key, value, timeout, TimeUnit.SECONDS);
        // }
        // return value;
        // 加入注解后，仅需 return business();

        // 此方法执行后，自动生成的缓存key为 AUTOCACHEDEMO_STRINGTEST_EMPTY_PARAM，缓存过期时间为300秒
        log.info("stringTest execution.");
        return UUID.randomUUID().toString();
    }

    @AutoCache
    public boolean booleanTest() {
        // 此方法执行后，自动生成的缓存key为 AUTOCACHEDEMO_BOOLEANTEST_EMPTY_PARAM，缓存过期时间为300秒
        log.info("booleanTest execution.");
        return Boolean.TRUE;
    }

    @AutoCache
    public int intTest() {
        // 此方法执行后，自动生成的缓存key为 AUTOCACHEDEMO_INTTEST_EMPTY_PARAM，缓存过期时间为300秒
        log.info("intTest execution.");
        return random.nextInt(100);
    }

    @AutoCache
    public List<String> listStringTest() {
        // 此方法执行后，自动生成的缓存key为 AUTOCACHEDEMO_LISTSTRINGTEST_EMPTY_PARAM，缓存过期时间为300秒
        log.info("listStringTest execution.");
        List<String> result = new ArrayList<>();
        result.add(UUID.randomUUID().toString());
        result.add(UUID.randomUUID().toString());
        result.add(UUID.randomUUID().toString());
        result.add(UUID.randomUUID().toString());
        result.add(UUID.randomUUID().toString());
        return result;
    }

    @AutoCache
    public List<Integer> listIntTest() {
        // 此方法执行后，自动生成的缓存key为 AUTOCACHEDEMO_LISTINTTEST_EMPTY_PARAM，缓存过期时间为300秒
        log.info("listIntTest execution.");
        List<Integer> result = new ArrayList<>();
        result.add(random.nextInt(100));
        result.add(random.nextInt(100));
        result.add(random.nextInt(100));
        result.add(random.nextInt(100));
        result.add(random.nextInt(100));
        return result;
    }

    @AutoCache
    public DemoEntity demoTest() {
        // 此方法执行后，自动生成的缓存key为 AUTOCACHEDEMO_DEMOTEST_EMPTY_PARAM，缓存过期时间为300秒
        log.info("demoTest execution.");
        DemoEntity demo = createDemo();
        demo.setList(listDemoTest());
        return demo;
    }

    private DemoEntity createDemo() {
        DemoEntity demo = new DemoEntity();
        demo.setId(random.nextInt(100));
        demo.setBool(true);
        demo.setDou(random.nextDouble());
        demo.setName("demo" + random.nextInt(100));
        demo.setTime(new Date());
        demo.setUuid(UUID.randomUUID().toString());
        return demo;
    }

    @AutoCache
    public List<DemoEntity> listDemoTest() {
        // 此方法执行后，自动生成的缓存key为 AUTOCACHEDEMO_LISTDEMOTEST_EMPTY_PARAM，缓存过期时间为300秒
        log.info("listDemoTest execution.");
        List<DemoEntity> result = new ArrayList<>();
        result.add(createDemo());
        result.add(createDemo());
        result.add(createDemo());
        result.add(createDemo());
        result.add(createDemo());
        return result;
    }

    @AutoCache
    public Map<String, Object> mapTest() {
        // 此方法执行后，自动生成的缓存key为 AUTOCACHEDEMO_MAPTEST_EMPTY_PARAM，缓存过期时间为300秒
        log.info("mapTest execution.");
        Map<String, Object> result = new HashMap<>();
        result.put("int", random.nextInt(100));
        result.put("boolean", true);
        result.put("string", UUID.randomUUID().toString());
        result.put("entity", demoTest());
        result.put("list", listDemoTest());
        result.put("double", random.nextDouble());
        result.put("date", new Date());
        Map<String, Object> map = new HashMap<>();
        map.put("test", "test");
        result.put("map",map);
        return result;
    }

    @AutoCache(ex = 500)
    public String keyTest(String str, int num, double dou, boolean boo) {
        // 此方法执行后，自动生成的缓存key为 AUTOCACHEDEMO_KEYTEST_"ckl"_21_3.4_true，缓存过期时间为500秒
        log.info("keyTest execution.");
        return "success";
    }

    @AutoCache
    public String entityKeyTest(DemoEntity demo) {
        // 此方法执行后，自动生成的缓存key为
        // AUTOCACHEDEMO_ENTITYKEYTEST_{"id":123,"name":"ckl","uuid":"test","time":null,"bool":false,"dou":0.0,"list":null}
        // 缓存过期时间为300秒
        log.info("entityKeyTest execution.");
        return "success";
    }

    @AutoCache(ex = 600, keyGenerator = "demoKeyGenerator")
    public String demoKeyTest(DemoEntity demo) {
        // 默认生成key的方式，对以自定义对象为入参的方法并不是那么适配，所以可以通过自实现的生成方式来修改生成的key
        // 此方法执行后，自动生成的缓存key为 AUTOCACHEDEMO_demokeytest_demo.getId，缓存过期时间为600秒
        log.info("demoKeyTest execution.");
        return "success";
    }

    // 在明确知道数据更新的时候，删除掉已有的缓存，
    public String removeKey() {
        DemoEntity demo = new DemoEntity();
        demo.setId(123);
        demo.setName("ckl");
        demo.setUuid("test");
        demoDelCacheService.demoKeyTest(demo);
        return "success";
    }


}
