package com.chinatower.autocache.demo.entity;

import java.util.Date;
import java.util.List;

/**
 * @author chenkonglin
 * Description
 * CreateDate 2022-12-29 13:49
 */
public class DemoEntity {
    private Integer id;
    private String name;
    private String uuid;
    private Date time;
    private boolean bool;
    private double dou;
    private List<DemoEntity> list;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public boolean isBool() {
        return bool;
    }

    public void setBool(boolean bool) {
        this.bool = bool;
    }

    public double getDou() {
        return dou;
    }

    public void setDou(double dou) {
        this.dou = dou;
    }

    public List<DemoEntity> getList() {
        return list;
    }

    public void setList(List<DemoEntity> list) {
        this.list = list;
    }

    @Override
    public String toString() {
        return "DemoEntity{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", uuid='" + uuid + '\'' +
                ", time=" + time +
                ", bool=" + bool +
                ", dou=" + dou +
                ", list=" + list +
                '}';
    }
}
