package com.chinatower.autocache.demo.service;

import com.chinatower.autocache.check.HitLog;
import com.chinatower.autocache.config.HitLogDealService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author chenkonglin
 * Description
 * CreateDate 2022-12-29 11:02
 * 直接使用 @Component 注解将其交由spring管理即可.
 */
@Slf4j
@Component
public class DemoHitLogDealService implements HitLogDealService {
    @Override
    public void deal(List<HitLog> list) {
        // 此数据可分析出项目内的缓存热点，缓存异常时的原因，项目热点时间，热点方法执行量，缓存的有效命中次数，缓存是否有效使用.
        // 可以将数据与密钥通过FeignClient推送至技术中台，技术中台将自动对数据进行保存，并显示出基础的数据分析结果。
        // 数据入库
        // logDao.save(list);
        // 记录日志文件
        // logWriter.write(list);
        // 实时分析
        // list.analysis();
        log.info(list.toString());
    }
}
