package com.chinatower.autocache.demo.service;

import com.chinatower.autocache.demo.entity.DemoEntity;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.Locale;

/**
 * @author chenkonglin
 * Description
 * CreateDate 2022-12-29 13:45
 */
@Component("demoKeyGenerator")
public class DemoKeyGenerator implements KeyGenerator {
    // 生成方式为 method.getName().toLowerCase()_demoEntityId
    @Override
    public Object generate(Object target, Method method, Object... params) {
        StringBuilder key = new StringBuilder(method.getName().toLowerCase(Locale.ROOT));
        if (params[0] != null) {
            DemoEntity entity = (DemoEntity) params[0];
            key.append("_").append(entity.getId());
        } else {
            key.append("_empty_param");
        }
        return key;
    }
}
