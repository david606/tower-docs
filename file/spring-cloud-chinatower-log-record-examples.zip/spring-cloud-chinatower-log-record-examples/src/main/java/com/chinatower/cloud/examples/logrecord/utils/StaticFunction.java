package com.chinatower.cloud.examples.logrecord.utils;

import com.chinatower.cloud.starter.logRecord.annotation.LogRecordFunc;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 静态自定义函数
 *
 * 使用注解的value属性指定函数名前缀为static
 */
@LogRecordFunc("static")
public class StaticFunction {
    /**
     * static方法，最终函数名：static_today
     */
    @LogRecordFunc
    public static String today() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        return format.format(new Date());
    }
}
