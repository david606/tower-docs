package com.chinatower.cloud.examples.logrecord.model;

/**
 * @author tonglsh3
 */
public class Birth {
    private String date;
    private String city;
    
    public Birth() {
    }
    
    public Birth(String date, String city) {
        this.date = date;
        this.city = city;
    }
    
    public String getDate() {
        return date;
    }
    
    public void setDate(String date) {
        this.date = date;
    }
    
    public String getCity() {
        return city;
    }
    
    public void setCity(String city) {
        this.city = city;
    }
    
    @Override
    public String toString() {
        return "Birth{" +
                "date='" + date + '\'' +
                ", city='" + city + '\'' +
                '}';
    }
}
