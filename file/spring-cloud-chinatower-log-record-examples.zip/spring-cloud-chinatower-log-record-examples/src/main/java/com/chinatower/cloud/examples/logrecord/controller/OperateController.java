package com.chinatower.cloud.examples.logrecord.controller;

import com.chinatower.cloud.examples.logrecord.model.User;
import com.chinatower.cloud.examples.logrecord.service.OperateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.util.Collections;

/**
 *
 * 操作日志示例
 *
 */
@RestController
@RequestMapping("/operate")
public class OperateController {
    @Autowired
    private OperateService operateService;
    
    // 基本用法
    @PostMapping("/changeUser")
    public void changeUser(@RequestBody User user) {
        operateService.changeUser(user);
    }
    
    // 记录返回值，会记录方法json序列化后的返回值
    @PostMapping("/changeUserWithReturn")
    public Object changeUserWithReturn(@RequestBody User user, HttpServletResponse response) {
        response.addHeader("X-test-header", "test");
        
        return operateService.changeUserWithReturn(user);
    }
    
    // 业务方法抛出异常，会记录异常信息：e.getMessage
    @PostMapping("/changeUserWithException")
    public void changeUserWithException(@RequestBody User user) {
        operateService.changeUserWithException(user);
    }
    
    // 自定义上下文
    @PostMapping("/customContext")
    public void customContext(@RequestBody User user) {
        operateService.customContext(user);
    }
    
    // 自定义函数
    @PostMapping("/customFunction")
    public void customFunction(@RequestBody User user) {
        operateService.customFunction(user);
    }
    
    // 根据条件记录日志
    @PostMapping("/condition")
    public void condition(@RequestBody User user) {
        operateService.condition(user);
    }
    
    // 全局操作人信息获取
    @PostMapping("/changeUserWithOperatorId")
    public void changeUserWithOperatorId(@RequestBody User user) {
        operateService.changeUserWithOperatorId(user);
    }
    
    // 全局操作人id和操作人姓名
    @PostMapping("/changeUserWithOperatorInfo")
    public void changeUserWithOperatorInfo(@RequestBody User user) {
        operateService.changeUserWithOperatorInfo(user);
    }
    
    // 实体类diff
    @PostMapping("/changeUserWithDiff")
    public void changeUserWithDiff(@RequestBody User user) {
        operateService.changeUserWithDiff(user);
    }
    
    // 可重复注解
    @PostMapping("/changeUserRepeatable")
    public void changeUserRepeatable(@RequestBody User user) {
        operateService.changeUserRepeatable(user);
    }
}
