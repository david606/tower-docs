package com.chinatower.cloud.examples.logrecord.controller;

import com.chinatower.cloud.examples.logrecord.feign.TestFeign;
import com.chinatower.cloud.examples.logrecord.feign.TestFeignGateway;
import org.apache.commons.lang3.RandomUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.security.SecureRandom;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 交互日志测试controller
 */
@RestController
public class TransController {
    private static final Integer FOR_NUMBER = 100;
    @Resource
    private TestFeign testFeign;
    
    @Resource
    private TestFeignGateway testFeignGateway;
    
    private final static AtomicInteger COUNT = new AtomicInteger(0);
    
    @Value("${server.port}")
    private int port;
    
    @GetMapping("/consumer")
    public Map<String, Object> consumer() {
        Map<String, Object> object = testFeign.provider();
        return object;
    }
    
    @GetMapping("/gw/getAllEnv")
    public Map<String, Object> gwGetAllEnv() {
        Map<String, Object> object = testFeignGateway.getAllEnv();
        return object;
    }
    
    @GetMapping("/gw/consumer/randomError")
    public Map<String, Object> gwConsumerRandomError() {
        Map<String, Object> object = testFeignGateway.randomError();
        return object;
    }
    
    @GetMapping("/consumer/randomError")
    public Map<String, Object> randomError() {
        Map<String, Object> object = testFeign.randomError();
        return object;
    }
    
    @GetMapping(value = "/consumer/params")
    public Object getParams(@RequestParam String id, @RequestParam String name) {
        return testFeign.getParams(id, name);
    }
    
    @PostMapping(value = "/consumer/params")
    public Object postParams(@RequestParam String id, @RequestParam String name) {
        return testFeign.postParams(id, name);
    }
    
    @PostMapping(value = "/consumer/upload")
    public Map<String, Object> upload(@RequestParam("file") MultipartFile file, HttpServletRequest request) {
        return testFeign.upload(file);
    }
    
    @PostMapping(value = "/consumer/body")
    public Object body(@RequestBody TestFeign.User user) {
        return testFeign.body(user);
    }
    
    @GetMapping(value = "/consumer/_404")
    public Object _404(@RequestParam String id) {
        return testFeign._404(id);
    }
    
    @RequestMapping("/all/result")
    public Map<String, Object> allresult() {
        // pass、block、succ、exception
        if(RandomUtils.nextInt(0, 100) % 10 == 0) {
            throw new RuntimeException("模拟10%异常");
        }
        
        SecureRandom random = new SecureRandom();
        long key = random.nextLong();
        long value = random.nextLong();
        Map<String, Object> result = new HashMap<>();
        for (int i = 0; i < FOR_NUMBER; i++) {
            result.put(String.valueOf(key + i), value + "value");
        }
        return result;
    }
    
    @GetMapping("/sleep")
    public Map<String, Object> sleep(@RequestParam(defaultValue = "50") Long millis) throws Exception{
        Thread.sleep(millis);
        return Collections.singletonMap("code", 0);
    }
    
    @GetMapping("/sleep/{millis}")
    public Map<String, Object> sleepMillis(@PathVariable Long millis) throws Exception{
        return sleep(millis);
    }
    
    @GetMapping("/sleep/random")
    public Map<String, Object> sleepRandom(@RequestParam(defaultValue = "10") Long min,
                                           @RequestParam(defaultValue = "100") Long max) throws Exception{
        Thread.sleep(RandomUtils.nextLong(min, max));
        return Collections.singletonMap("code", 0);
    }
    
    @GetMapping("/fixErrorRate")
    public Map<String, Object> fixErrorRate(@RequestParam(value = "rate", defaultValue = "50") Integer rate) {
        if(RandomUtils.nextInt(0, 100) <= rate) {
            throw new RuntimeException("固定比例异常：" + rate + "%" );
        }
        return Collections.singletonMap("result", "success");
    }
    
    @GetMapping("/origin")
    public Map<String, Object> origin() {
        return Collections.singletonMap("code", 0);
    }
    
    @GetMapping("/requestBodyMap")
    public Object requestBodyMap(@RequestBody Map<String, Object> map) {
        return map;
    }
    @PostMapping("/requestBodyUser")
    public Object requestBodyUser(@RequestBody User user) {
        return user;
    }
    
    @GetMapping("/t1")
    public Map<String, Object> test1(HttpServletRequest request) {
    
        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String headerName = headerNames.nextElement();
            System.out.println(headerName + ": " + request.getHeader(headerName));
        }
    
        String traceId = MDC.get("traceId");
        String spanId = MDC.get("spanId");
        System.out.println("traceId: " + traceId + ", spanId: " + spanId);
        
        Map<String, Object> result = new HashMap<>();
        return result;
    }
    
    @GetMapping("/t2")
    public String test2(String arg) {
        int i = COUNT.incrementAndGet();
        System.out.println("count="+i+"  arg=" + arg);
        return arg;
    }
    
    public static class User {
        private String name;
        private Job job;
        
        public static class Job {
            private String company;
            
            public String getCompany() {
                return company;
            }
            
            public void setCompany(String company) {
                this.company = company;
            }
        }
    
        public String getName() {
            return name;
        }
    
        public void setName(String name) {
            this.name = name;
        }
    
        public Job getJob() {
            return job;
        }
    
        public void setJob(Job job) {
            this.job = job;
        }
    }

}

