package com.chinatower.cloud.examples.logrecord.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static net.logstash.logback.argument.StructuredArguments.entries;

/**
 * @author tonglsh3
 */
@RestController
@RequestMapping("/system")
public class SystemController {
    private Logger log = LoggerFactory.getLogger(SystemController.class);
    
    private Logger systemLog = LoggerFactory.getLogger("systemLog");
    
    @GetMapping("/info")
    public void info() {
        Map<String, Object> map = new HashMap<>();
        map.put("id", 1000);
        map.put("name", "zhangsan");
        map.put("city", Collections.singletonMap("province", "hebei"));
        log.info("system info finish", entries(map));
        systemLog.info("systemLog info finish~~~");
    }
    
    @GetMapping("/error")
    public void error() {
        RuntimeException t = new RuntimeException("ops exception!!");
        log.error("发生异常", t);
        systemLog.error("发生异常", t);
    }
    
    @GetMapping("/error/cause")
    public void cause() {
        RuntimeException t = new RuntimeException("ops exception!!", new NullPointerException("ops null!!"));
        log.error("发生异常", t);
        systemLog.error("发生异常", t);
    }
}
