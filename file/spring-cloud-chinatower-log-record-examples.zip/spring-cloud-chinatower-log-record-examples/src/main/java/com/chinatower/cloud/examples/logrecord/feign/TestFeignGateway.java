package com.chinatower.cloud.examples.logrecord.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Map;

/**
 * @author qiaowh
 */
@FeignClient(value = "INNER-GATEWAY",url="10.180.22.22:8097",
        fallbackFactory = TestFeignGatewayFallbackFactory.class)
public interface TestFeignGateway {
    
    @GetMapping("CHNTMID-PLATFORM-SOA-SERVICE/basic/getAllEnv")
    public Map<String, Object> getAllEnv();
    
    @GetMapping("CHNTSENTINEL-TEST-OLD/provider")
    public Map<String, Object> provider();
    
    @GetMapping("CHNTSENTINEL-TEST-OLD/provider/randomError")
    public Map<String, Object> randomError();
    
    @GetMapping("CHNTSENTINEL-TEST-OLD/provider/slow")
    public Map<String, Object> slow(Long millis);


}
