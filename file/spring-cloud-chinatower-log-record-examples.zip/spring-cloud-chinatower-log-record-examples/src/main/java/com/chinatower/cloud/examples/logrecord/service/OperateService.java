package com.chinatower.cloud.examples.logrecord.service;

import com.chinatower.cloud.starter.logRecord.annotation.LogRecordFunc;
import com.chinatower.cloud.starter.logRecord.annotation.OperationLog;
import com.chinatower.cloud.starter.logRecord.annotation.OperationLogs;
import com.chinatower.cloud.starter.logRecord.context.LogRecordContext;
import com.chinatower.cloud.examples.logrecord.model.Birth;
import com.chinatower.cloud.examples.logrecord.model.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Map;

/**
 * @author tonglsh3
 */
@Service
@LogRecordFunc
public class OperateService {
    private static Logger log = LoggerFactory.getLogger(OperateService.class);
    
    @OperationLog(bizId = "'changeUser'", bizType = "'user'", msg = "'修改用户信息，用户id：' + #user.id")
    public boolean changeUser(User user) {
        log.info("changeUser finish, user: {}", user);
        return true;
    }
    
    @OperationLog(bizId = "'changeUserWithReturn'", bizType = "'user'", msg = "'修改用户信息，用户id：' + #user.id", recordReturnValue = true)
    public User changeUserWithReturn(User user) {
        log.info("changeUser finish, user: {}", user);
        return user;
    }
    
    @OperationLog(bizId = "'changeUserWithException'", bizType = "'user'", msg = "'修改用户信息，用户id：' + #user.id", recordReturnValue = true)
    public User changeUserWithException(User user) {
        throw new RuntimeException("Ops exception!!!");
    }
    
    @OperationLog(bizId = "'customContext'", bizType = "'user'", msg = "'修改用户信息，用户部门：' + #department")
    public boolean customContext(User user) {
        LogRecordContext.putVariable("department", "研发部");
        log.info("customContext finish, user: {}", user);
        return true;
    }
    
    @OperationLog(bizId = "'customFunction'", bizType = "'user'", msg = "'修改用户信息，用户生日：' + #getUser(#user.id).birth.date + ', 时间：' + #static_today()")
    public void customFunction(User user) {
        log.info("customFunction finish, user: {}", user);
    }
    
    @OperationLog(bizId = "'condition'", bizType = "'user'", condition = "#user.id != 'admin'", msg = "'修改用户信息，用户id：' + #user.id")
    public void condition(User user) {
        log.info("customFunction finish, user: {}", user);
    }
    
    @OperationLog(bizId = "'changeUserWithOperatorId'", bizType = "'user'", msg = "'修改用户信息，用户id：' + #user.id")
    public void changeUserWithOperatorId(User user) {
        log.info("changeUserWithOperatorId finish, user: {}", user);
    }
    
//    @OperationLog(bizId = "'changeUserWithOperatorInfo'", bizType = "'user'", msg = "'修改用户信息，用户id：' + #user.id",
//    operatorId = "'zhangsan'", operatorName = "'张三'")
    @OperationLog(bizId = "'changeUserWithOperatorInfo'", bizType = "'user'", msg = "'修改用户信息，用户id：' + #user.id")
    public void changeUserWithOperatorInfo(User user) {
        log.info("changeUserWithOperatorInfo finish, user: {}", user);
    }
    
    @OperationLog(bizId = "'changeUserWithDiff'", bizType = "'user'", msg = "'修改用户信息，用户id：' + #user.id",
            extra = "#_DIFF(#oldUser, #user)", recordReturnValue = true)
    public Map<String, Object> changeUserWithDiff(User user) {
        LogRecordContext.putVariable("oldUser", getOldUser(user));
        log.info("changeUserWithDiff finish, user: {}", user);
        return Collections.singletonMap("code", "success");
    }
    
    @OperationLog(bizId = "'changeUserRepeatable1'", bizType = "'user'", msg = "'修改用户信息，用户id：' + #user.id")
    @OperationLog(bizId = "'changeUserRepeatable2'", bizType = "'user'", msg = "'change user info，user id：' + #user.id")
    public boolean changeUserRepeatable(User user) {
        log.info("changeUserRepeatable finish, user: {}", user);
        return true;
    }
    
    // 需要为public方法，否则会报错：org.springframework.expression.spel.SpelEvaluationException: EL1006E: Function 'queryUserDepartment' could not be found
    @LogRecordFunc
    public String queryUserDepartment(String id) {
        log.info("queryUserDepartment id: {}", id);
        return "销售部门";
    }
    
    // 查询用户修改前的信息
    private User getOldUser(User user) {
        User oldUser = new User();
        oldUser.setId(user.getId());
        oldUser.setName("旧名字");
        
        oldUser.setBirth(new Birth("2023-06-06", "beijing"));
        
        return oldUser;
    }
}
