package com.chinatower.cloud.examples.logrecord.service;

import com.chinatower.cloud.starter.logRecord.service.IOperatorIdGetService;
import org.springframework.stereotype.Component;

@Component
public class IOperatorIdGetServiceImpl implements IOperatorIdGetService {
    @Override
    public String getOperatorId() {
        return "lisi";
    }
    
    @Override
    public String getOperatorName() throws Exception {
        return "李四";
    }
}