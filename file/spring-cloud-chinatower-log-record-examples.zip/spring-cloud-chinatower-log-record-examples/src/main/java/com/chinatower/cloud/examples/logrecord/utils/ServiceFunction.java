package com.chinatower.cloud.examples.logrecord.utils;

import com.chinatower.cloud.examples.logrecord.model.Birth;
import com.chinatower.cloud.examples.logrecord.model.User;
import com.chinatower.cloud.starter.logRecord.annotation.LogRecordFunc;
import org.springframework.stereotype.Service;

import java.util.UUID;

/**
 * Spring Service作为自定义函数
 */
@LogRecordFunc
@Service
public class ServiceFunction {
    /**
     * 最终函数名：uuid
     */
    @LogRecordFunc
    public String uuid() {
        return UUID.randomUUID().toString();
    }
    
    /**
     * 使用注解的value属性定义函数名，最终函数名：getUser
     */
    @LogRecordFunc("getUser")
    public User user(String id) {
        // 根据id查询用户
        User user = new User();
        user.setId(id);
        user.setName("zhangsan");
        user.setAge(25);
        user.setBirth(new Birth("2000-06-29", "beijing"));
        return user;
    }
}
