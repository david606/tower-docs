package com.chinatower.cloud.examples.logrecord.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

/**
 * @author qiaowh
 */
@FeignClient(name = "chntsentinel-test-old")
public interface TestFeign {
    
    @GetMapping("/provider")
    public Map<String, Object> provider();
    
    @GetMapping("/provider/randomError")
    public Map<String, Object> randomError();
    
    @GetMapping("/provider/slow")
    public Map<String, Object> slow(@RequestParam("millis") Long millis);
    
    
    @GetMapping(value = "/provider/params")
    public Object getParams(@RequestParam(value = "id") String id, @RequestParam(value = "name") String name);
    
    @PostMapping(value = "/provider/params")
    public Object postParams(@RequestParam(value = "id") String id, @RequestParam(value = "name") String name);
    
    @PostMapping(value = "/provider/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, Object> upload(@RequestPart("file") MultipartFile file);
    
    @PostMapping(value = "/provider/body")
    public Object body(@RequestBody User user);
    
    @GetMapping(value = "/provider/xxxxx")
    public Object _404(@RequestParam(value = "id") String id);
    
    public static class User {
        private Integer id;
        private String name;
        private City city;
    
        public static class City {
            private String province;
            private String regin;
        
            public String getProvince() {
                return province;
            }
        
            public void setProvince(String province) {
                this.province = province;
            }
        
            public String getRegin() {
                return regin;
            }
        
            public void setRegin(String regin) {
                this.regin = regin;
            }
        }
    
        public Integer getId() {
            return id;
        }
    
        public void setId(Integer id) {
            this.id = id;
        }
    
        public String getName() {
            return name;
        }
    
        public void setName(String name) {
            this.name = name;
        }
    
        public City getCity() {
            return city;
        }
    
        public void setCity(City city) {
            this.city = city;
        }
    }
    
}
