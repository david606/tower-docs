package com.chinatower.cloud.examples.logrecord.feign;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.openfeign.FallbackFactory;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.Map;

/**
 *
 *
 * 对于FallbackFactory
 * 新框架openfeign不依赖feign-hystrix包，所以没有{@link feign.hystrix.FallbackFactory}这个类，应
 * 使用spring-cloud-openfeign-core包里的{@link org.springframework.cloud.openfeign.FallbackFactory}
 *
 * @author tonglsh3
 */
@Component
public class TestFeignGatewayFallbackFactory implements FallbackFactory<TestFeignGateway> {
    private static Logger log = LoggerFactory.getLogger(TestFeignGatewayFallbackFactory.class);
    
    @Override
    public TestFeignGateway create(Throwable throwable) {
        return new TestFeignGateway() {
            @Override
            public Map<String, Object> getAllEnv() {
                System.out.println("fallback getAllEnv: " + throwable);
                return null;
            }

            @Override
            public Map<String, Object> provider() {
                System.out.println("fallback provider");
                return null;
            }

            @Override
            public Map<String, Object> randomError() {
                log.warn(String.format("fallback randomError, exception: %s, ", throwable.getClass().getCanonicalName()), throwable);
                return Collections.singletonMap("info", "fallback randomError");
            }

            @Override
            public Map<String, Object> slow(Long millis) {
                System.out.println("fallback slow");
                return null;
            }
        };
    }
}
