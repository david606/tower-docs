//package cn.com.chinatower.lock.controller;
//
//import cn.com.chinatower.lock.service.TowerLock;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
///**
// * 中国铁塔分布式锁：redis直连模式使用demo
// */
//@RestController
//@RequestMapping("/tower")
//public class TowerLockController {
//
//    @Autowired
//    private TowerLock towerLock;
//
//    /**
//     * 避免分布式系统下，不同节点重复相同的工作。
//     * 例：一个微服务需要部署到多台服务上，这个微服务当中有个定时任务，需保证同一时间只有一台服务上可以执行该定时任务
//     *
//     * @return
//     */
//    @RequestMapping("/lockDemo")
//    public String lockDemo() {
//        // lockName : 锁名
//        String lockName = "myLock_executeTask";
//        try {
//            // api1: lock(String lockName);
//            // api2: lock(String lockName, long leaseTime);
//            // api3: tryLock(String lockName, long waitTime);
//            // api4: tryLock(String lockName, long leaseTime, long waitTime);
//            // 1.获取分布式锁(获取锁的4种api，根据自己的需求，合理选择使用哪种api)
//            boolean lock = towerLock.lock(lockName);
//            System.out.println("lock:" + lock);
//            // 2.执行业务逻辑
//            if (lock) {
//                scheduledTask();
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // 3.释放分布式锁
//            // 释放分布式锁最好放在finally里面，防止业务逻辑执行异常，未能及时释放掉锁
//            towerLock.unlock(lockName);
//        }
//        return "success";
//    }
//
//    public void scheduledTask() {
//        System.out.println("do your scheduled task ...");
//    }
//}
