package cn.com.chinatower.lock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DistributedLockDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
