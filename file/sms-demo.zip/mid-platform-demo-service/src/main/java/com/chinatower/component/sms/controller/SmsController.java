package com.chinatower.component.sms.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.chinatower.util.Util;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@Slf4j
@RestController
@RequestMapping("/sms")
public class SmsController {

    // 短信组件发送短信url
    private final String smsUrl = "http://ip:port/sms/asyncOne";

    /**
     * @param phone        手机号
     * @param msg          短信内容，Json字符串格式，用来填充模板中的占位符。 例：{"key":"value"}
     * @param url          回调url，可不填
     * @param signCode     短信签名code
     * @param templateCode 短信模板code
     * @param privateKey   密钥
     * @param sysCode      系统编码
     * @return
     * @throws Exception
     */
    @PostMapping("/asyncOne")
    public String asyncOne(@RequestParam(value = "phone", required = true) String phone,
                           @RequestParam(value = "msg", required = true) String msg,
                           @RequestParam(value = "url", required = false) String url,
                           @RequestParam(value = "signCode", required = true) String signCode,
                           @RequestParam(value = "templateCode", required = true) String templateCode,
                           @RequestParam(value = "privateKey", required = true) String privateKey,
                           @RequestParam(value = "sysCode", required = true) String sysCode) throws Exception {
        String result = "";

        String timestamp = System.currentTimeMillis() + "";
        String nonce = timestamp;
        String token = Util.creterSM2Signature(timestamp, timestamp, sysCode, privateKey);

        HttpHeaders headers = new HttpHeaders();
        headers.add("timestamp", timestamp);
        headers.add("nonce", nonce);
        headers.add("sysCode", sysCode);
        headers.add("token", token);

        LinkedMultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("phone", phone);
        params.add("msg", msg);
        params.add("url", url);
        params.add("signCode", signCode);
        params.add("templateCode", templateCode);
        HttpEntity<LinkedMultiValueMap<String, String>> requestEntity = new HttpEntity<>(params, headers);
        log.info("调用短信组件 http请求入参 smsUrl:{}, requestEntity:{}", smsUrl, requestEntity);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> responseEntity = restTemplate.postForEntity(smsUrl, requestEntity, String.class);
        log.info("调用短信组件 http请求响应responseEntity:{}", responseEntity);
        if (responseEntity.getStatusCodeValue() == 200) {
            String body = responseEntity.getBody();
            JSONObject json = JSON.parseObject(body);
            String resultStat = json.getString("resultStat");
            result = json.getString("mess");
        } else {
            result = "调用短信组件发送短信失败！";
        }
        return result;
    }

}
