package com.chinatower.kafka.framework.producer;

import com.chinatower.framework.mq.kafka.api.KafkaUtils;
//import com.chinatower.framework.mq.kafka.api.KafkaUtils2;
import com.chinatower.framework.mq.kafka.api.KafkaUtils2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value = "producer")
public class producer {

    @Autowired
    private KafkaUtils kafkaUtils;

    @Autowired
    private KafkaUtils2 kafkaUtils2;
    /**
     *  同步发送消息
     * @return
     */

    @RequestMapping(value = "syncSend",method = RequestMethod.GET)
    public String syncSend(@RequestParam String topic,@RequestParam String message){
//        String topic = "test_topic";
//        String message = "这是一个测试数据11111111。";
        kafkaUtils.syncSend(topic, message);
        return "同步发送消息成功。";
    }

    @RequestMapping(value = "syncSend2",method = RequestMethod.GET)
    public String syncSend2(){
        String topic = "test_topic2";
        String message = "这是一个测试数据222222222。";
        kafkaUtils2.syncSend(topic, message);
        return "同步发送消息成功。";
    }

    /**
     * 指定 kafkaMessageId 同步发送消息
     * @param topic
     * @param message
     * @param kafkaMessageId
     * @return
     */
//    @RequestMapping(value = "syncSendByKafkaMessageId",method = RequestMethod.GET)
//    public String syncSendByKafkaMessageId(String topic, String message, String kafkaMessageId){
//        topic = "test_topic";
//        message = "这是一个测试数据。";
//        kafkaMessageId =  "kafkaMessageId_test001";
//        kafkaUtils.syncSend(topic, message,kafkaMessageId);
//        return "指定 kafkaMessageId 同步发送消息成功。";
//    }

    /**
     * 异步发送消息
     * @return
     */
    @RequestMapping(value = "asyncSend",method = RequestMethod.GET)
    public String asyncSend(){
        String topic = "test_topic";
        String message = "这是一个测试数据。";
        kafkaUtils.asyncSend(topic, message);
        return "异步发送消息成功。";
    }

    /**
     *  批量发送消息
     * @param topic
     * @param messages
     * @return
     */
    @RequestMapping(value = "batchSend",method = RequestMethod.GET)
    public String batchSend(String topic, List<String> messages) {
        topic = "test_topic";
        for (int i = 0;i < 10;i++) {
            messages.add("这是一个测试数据 " + i);
        }
        kafkaUtils.batchSend(topic, messages);
        return "批量发送消息成功。";
    }

    /**
     * 指定 key 同步发送消息成功
     * @return
     */
//    @RequestMapping(value = "syncSendByKey",method = RequestMethod.GET)
//    public String syncSendByKey(){
//        String topic = "test_topic";
//        String message = "这是一个测试数据。";
//        String key =  "sync_key_test001";
//        kafkaUtils.syncSendByKey(topic,key, message);
//        return "指定 key 同步发送消息成功。";
//    }

    /**
     *  指定 key 异步发送消息成功
     * @return
     */
//    @RequestMapping(value = "asyncSendByKey",method = RequestMethod.GET)
//    public String asyncSendByKey(){
//        String topic = "test_topic";
//        String message = "这是一个测试数据。";
//        String key =  "async_key_test001";
//        kafkaUtils.asyncSendByKey(topic,key, message);
//        return "指定 key 异步发送消息成功。";
//    }
}
