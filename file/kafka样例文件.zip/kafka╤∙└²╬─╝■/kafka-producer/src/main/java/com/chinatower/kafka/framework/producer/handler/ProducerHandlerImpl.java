package com.chinatower.kafka.framework.producer.handler;

import com.chinatower.framework.mq.kafka.handler.ProducerHandler;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Primary
@Component
@Slf4j
public class ProducerHandlerImpl implements ProducerHandler {
    @Override
    public void onSuccess(ProducerRecord producerRecord, RecordMetadata recordMetadata) {
        log.info("发送消息成功：{}", producerRecord.toString());
    }

    @Override
    public void onError(ProducerRecord producerRecord, Exception recordMetadata) {
        log.info("发送消息失败：{}", producerRecord.toString());
    }
//    @Override
//    public void onSuccess(ProducerRecord<?, ?> producerRecord, RecordMetadata recordMetadata) {
//        log.info("发送消息成功：{}", producerRecord.toString());
//    }
//
//    @Override
//    public void onError(ProducerRecord<?, ?> producerRecord, Exception recordMetadata) {
//        log.info("发送消息失败：{}", producerRecord.toString());
//    }
}
