package com.chinatower.framework.consumer;

import com.chinatower.framework.mq.kafka.consumer.ConsumerMessage;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.context.annotation.Primary;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Primary
@Component
@Slf4j
public class DefaultConsumerMessage implements ConsumerMessage {
    @Override
    @KafkaListener(topics = {"test_topic"}, groupId = "${kafka.consumer.group-id}", errorHandler = "consumerAwareErrorHandler",containerFactory = "kafkaListenerContainerFactory")
    public <T> T ack(ConsumerRecord<?, ?> consumerRecord) {
        String topic=consumerRecord.topic();

        log.info(topic + " value is11111111" + consumerRecord.value().toString());

//        switch (topic) {
//            case "demoTopA":
//                //TODO demoTopA 主题
//                log.info("demoTopA value is" + consumerRecord.value().toString());
//                break;
//            case "demoTopB":
//                //TODO demoTopB主题
//                log.info("demoTopB value is" + consumerRecord.value().toString());
//                break;
//            case "demoTopC":
//                //TODO demoTopB主题
//                log.info("demoTopC value is" + consumerRecord.value().toString());
//                break;
//            case "demoTopD":
//                //TODO demoTopB主题
//                log.info("demoTopD value is" + consumerRecord.value().toString());
//                break;
//            case "demoTopE":
//                //TODO demoTopE主题
//                log.info("demoTopE value is" + consumerRecord.value().toString());
//                break;
//            default:
//                break;
//        }
        return null;
    }

//    @Override
////    @KafkaListener(topics = {"test_topic","test_topic2"}, groupId = "${kafka.consumer.group-id}", errorHandler = "consumerAwareErrorHandler",containerFactory = "kafkaListenerContainerFactory")
//    @KafkaListener(topics = "#{'${kafka.consumer.topic-name}'.split(',')}", groupId = "${kafka.consumer.group-id}", errorHandler = "consumerAwareErrorHandler",containerFactory = "kafkaListenerContainerFactory")
//    public <T> T ack(ConsumerRecord consumerRecord) {
//        String topic=consumerRecord.topic();
//
//        log.info(topic + " value is11111111" + consumerRecord.value().toString());
//        return null;
//    }
}
