//package com.chinatower.framework.consumer;
//
//import com.chinatower.framework.mq.kafka.consumer.ConsumerMessage;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.kafka.clients.consumer.ConsumerRecord;
//import org.springframework.kafka.annotation.KafkaListener;
//import org.springframework.stereotype.Component;
//
////package com.chinatower.framework.consumer;
////
////import com.chinatower.framework.mq.kafka.consumer.ConsumerMessage;
////import lombok.extern.slf4j.Slf4j;
////import org.apache.kafka.clients.consumer.ConsumerRecord;
////import org.springframework.kafka.annotation.KafkaListener;
////import org.springframework.stereotype.Component;
////
//@Component
//@Slf4j
//public class DefaultConsumerMessage2 implements ConsumerMessage {
//    @Override
//    @KafkaListener(topics = {"test_topic"}, groupId = "${kafka.consumer.group-id}", errorHandler = "consumerAwareErrorHandler",containerFactory = "kafkaTwoListenerContainerFactory")
//    public <T> T ack(ConsumerRecord<?, ?> consumerRecord) {
//        String topic=consumerRecord.topic();
//
//        log.info(topic + " value is222222" + consumerRecord.value().toString());
//        return null;
//    }
//
//
////    @Override
////    @KafkaListener(topics = {"test_topic2"}, groupId = "${kafka.consumer.group-id}", errorHandler = "consumerAwareErrorHandler",containerFactory = "kafkaTwoListenerContainerFactory")
////    public <T> T ack(ConsumerRecord consumerRecord) {
////        String topic=consumerRecord.topic();
////
////        log.info(topic + " value is22222222222" + consumerRecord.value().toString());
////        return null;
////    }
//}
