package com.chinatower.framework.consumer.filter;

import com.chinatower.framework.mq.kafka.filter.CustomFilter;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Primary
@Component
public class CustomFilterImpl implements CustomFilter {
    @Override
    public boolean rule(ConsumerRecord<?, ?> consumerRecord) {
        System.out.println(consumerRecord.value());
        String value = consumerRecord.value().toString();
        // 假设value中包含"error"字符串的记录为错误记录
        // 可以根据具体需求修改判断逻辑
        if (value.contains("error")) {
            return true;
        }else {

        }
        return false;
    }

//    @Override
//    public boolean rule(ConsumerRecord consumerRecord) {
//        return false;
//    }
}
